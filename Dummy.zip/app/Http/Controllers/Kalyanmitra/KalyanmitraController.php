<?php

namespace App\Http\Controllers\Kalyanmitra;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;

class KalyanmitraController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:kalyanmitra_dashboard');
        $this->middleware(function ($request, $next) {
            if (empty(Auth::user()->email_verified_at)) {
                Redirect::to('kalyanmitra/email/verify')->send();
            }
            return $next($request);
        });
    }

    /**
     * This function is used to load the vendor home page
     */

    public function index()
    {
        return view('kalyanmitra/home');
    }
}
