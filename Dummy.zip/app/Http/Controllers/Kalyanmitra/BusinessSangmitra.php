<?php

namespace App\Http\Controllers\Kalyanmitra;

use App\Http\Controllers\Controller;
use App\mitra_busines;
use App\mitra_common_details;
use App\service;
use App\states;
use App\sub_service;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Vinkla\Hashids\Facades\Hashids;

class BusinessSangmitra extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:kalyanmitra_dashboard');
        $this->middleware(function ($request, $next) {
            if (empty(Auth::user()->email_verified_at)) {
                Redirect::to('kalyanmitra/email/verify')->send();
            }
            return $next($request);
        });
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $result = mitra_busines::latest()->paginate();
        return view('kalyanmitra/index_business_sangmitra', compact('result'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        session_start();
        session_unset();
        session_destroy();
        $service = service::where('active', '=', 1)->get();
        $states = states::where('country_id', '=', 101)->get();
        return view('kalyanmitra/create_business_sangmitra', compact('service', 'states'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {
            session_start();
            // session_destroy();exit;
            $request_data = $request->all();
            // printR($_SESSION);
            $messages = [
                'sub_services.required' => 'Please select sub service',
            ];
            $validator = Validator::make($request->all(), [
                'services_id' => 'required',
                'sub_services' => 'required',
                'description' => 'required',
                'name' => 'required',
                'email' => 'string', 'email', 'max:255', 'unique:mitra_common_details',
                'mobile' => 'required|numeric|digits:10',
                'gender' => 'required',
                'dob' => 'required',
                'father_name' => 'required',
                'state' => 'required',
                'city' => 'required',
                'district' => 'required',
                'pincode' => 'required',
                'aadhar_number' => 'required|numeric|digits:12|unique:mitra_common_details',
                'locality_landmark' => 'required',
                'work_name' => 'required',
                'working_address' => 'required',
            ], $messages);
            if ($validator->fails()) {
                $data = $validator->errors()->toArray();
                foreach ($data as $key => $value) {
                    $message = $value[0];
                    return response()->json(['icon' => 'error', 'title' => 'Please fill required details', 'msg' => $message]);
                    exit;
                }
            } else {
                if (empty($_SESSION['profile_photo'])) {
                    return response()->json(['icon' => 'error', 'title' => 'Please fill required details', 'msg' => 'Please Upload Profile Photo']);
                    exit;
                }
                if (empty($_SESSION['aadhar_photo'])) {
                    return response()->json(['icon' => 'error', 'title' => 'Please fill required details', 'msg' => 'Please Upload Aadhar Photo']);
                    exit;
                }
                $user_id = Auth::user()->id;
                if (empty($_SESSION['sangmitra_id'])) {
                    $create_sangmitra_id = 'BOL-' . time();
                    $_SESSION['sangmitra_id'] = $create_sangmitra_id;
                } else {
                    $create_sangmitra_id = $_SESSION['sangmitra_id'];
                }
                // Seprate mitra common table
                $mitra_common_table = [
                    'sangmitra_id' => $create_sangmitra_id,
                    'aadhar_number' => $request_data['aadhar_number'],
                    'email' => $request_data['email'],
                    'name' => $request_data['name'],
                    'father_name' => $request_data['father_name'],
                    'dob' => $request_data['dob'],
                    'mobile' => $request_data['mobile'],
                    'alternet_mobile' => $request_data['alternet_mobile'],
                    'gender' => $request_data['gender'],
                    'profile_photo' => json_encode($_SESSION['profile_photo']),
                    'state_id' => $request_data['state'],
                    'city_id' => $request_data['city'],
                    'district' => $request_data['district'],
                    'pincode' => $request_data['pincode'],
                    'locality_landmark' => $request_data['locality_landmark'],
                ];
                $insert_id = mitra_common_details::create($mitra_common_table);
                // mitra_busines
                $mitra_busines_table = [
                    'mitra_id' => $insert_id->id,
                    'services' => $_SESSION['services_id'],
                    'sub_services' => $_SESSION['sub_services'],
                    'services_desciption' => $request_data['description'],
                    'work_name' => $request_data['work_name'],
                    'working_address' => $request_data['working_address'],
                    'gst_number' => $request_data['gst_number'],
                    'aadhar_photo' => json_encode($_SESSION['aadhar_photo']),
                    'working_documents' => json_encode($_SESSION['working_documents']),
                    'work_photos' => json_encode($_SESSION['work_photos']),

                ];
                // printR($mitra_busines_table);
                $insert_id_two = mitra_busines::create($mitra_busines_table);
                session_unset();
                session_destroy();
                return response()->json(['icon' => 'success', 'title' => 'Success', 'msg' => 'Data insert or update successfully']);

            }
        } catch (\Exception $e) {
            return response()->json(['icon' => 'error', 'title' => 'Error', 'msg' => $e->getMessage()]);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $id = Hashids::decode($id);
        $result = mitra_busines::find($id[0]);
        return view('kalyanmitra/view', compact('result'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $id = Hashids::decode($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        try {
            $id = Hashids::decode($id);
            $mitra_busines = mitra_busines::find($id[0]);
            $mitra_busines->delete();
            return response()->json(['icon' => 'success', 'title' => 'Success', 'msg' => 'Business Sangmitra Delete Successfully !']);
        } catch (\Exception $e) {
            return response()->json(['icon' => 'error', 'title' => 'Error', 'msg' => $e->getMessage()]);
        }
    }

    /**
     * This function is used to append sub-service
     *
     * @param of service id
     * @return sub_service
     */
    public function appendSubservice(Request $request)
    {
        try {
            $request_data = $request->all();
            $messages = [
                'services_id.required' => 'Please select service',
            ];
            $validator = Validator::make($request->all(), [
                'services_id' => 'required',
            ], $messages);
            if ($validator->fails()) {
                $data = $validator->errors()->toArray();
                foreach ($data as $key => $value) {
                    $message = $value[0];
                    return response()->json(['icon' => 'error', 'title' => 'Please fill required details', 'msg' => $message]);
                    exit;
                }
            } else {
                foreach ($request_data['services_id'] as $id) {
                    $sub_services[] = sub_service::where('services_id', '=', $id)
                        ->where('active', '=', 1)->get();
                }
                $view = view('kalyanmitra/sub_service_data_ajax', ['sub_services' => $sub_services])->render();
                return response()->json(['sub_services' => $view, 'list' => 'list']);
            }
        } catch (\Exception $e) {
            return response()->json(['icon' => 'error', 'title' => 'Error', 'msg' => $e->getMessage()]);
        }
    }

    /**
     * This function is used to upload profile image
     *
     * @param of image in array
     * @return \Illuminate\Http\Response
     */

    public function uploadProfileImage(Request $request)
    {
        try {
            session_start();
            $request_data = $request->all();
            $dir = $request_data['dir'];
            //get filename with extension
            $filenamewithextension = $request->file('file')->getClientOriginalName();
            if (empty($_SESSION['sangmitra_id'])) {
                $create_sangmitra_id = 'BOL-' . time();
                $_SESSION['sangmitra_id'] = $create_sangmitra_id;
                $_SESSION['dir'] = $request_data['dir'];
            } else {
                $create_sangmitra_id = $_SESSION['sangmitra_id'];
            }
            $profile_img_path = '/assets/images/sangmitra/' . $dir . '/' . $create_sangmitra_id . '/profile_photo/';
            $filenametostore_cover = uploadImage($request, $request_data['file'], $profile_img_path);
            $_SESSION['profile_photo'][$filenamewithextension] = $filenametostore_cover;
            return $filenametostore_cover;
        } catch (Exception $e) {
            return response()->json(['icon' => 'error', 'title' => 'Error', 'msg' => $e->getMessage()]);
        }
    }

    /**
     * This function is used to destroy profile images
     *
     * @param of image name
     * @return \Illuminate\Http\Response
     */

    public function fileDestroyProfile(Request $request)
    {
        try {
            session_start();
            $sangmitra_id = $_SESSION['sangmitra_id'];
            $request_data = $request->all();
            $dir = $request_data['dir'];
            $filename = $request->get('filename');
            $path = public_path() . '/assets/images/sangmitra/' . $dir . '/' . $sangmitra_id . '/profile_photo/' . $_SESSION['profile_photo'][$filename];
            if (file_exists($path)) {
                unlink($path);
            }
            unset($_SESSION['profile_photo'][$filename]);
            return $filename;
        } catch (Exception $e) {
            return response()->json(['icon' => 'error', 'title' => 'Error', 'msg' => $e->getMessage()]);
        }
    }

    /**
     * This function is used to upload aadhar image
     *
     * @param of image in array
     * @return \Illuminate\Http\Response
     */

    public function uploadAadharImage(Request $request)
    {
        try {
            session_start();
            $request_data = $request->all();
            $dir = $request_data['dir'];
            //get filename with extension
            $filenamewithextension = $request->file('file')->getClientOriginalName();
            if (empty($_SESSION['sangmitra_id'])) {
                $create_sangmitra_id = 'BOL-' . time();
                $_SESSION['sangmitra_id'] = $create_sangmitra_id;
                $_SESSION['dir'] = $request_data['dir'];
            } else {
                $create_sangmitra_id = $_SESSION['sangmitra_id'];
            }
            $profile_img_path = '/assets/images/sangmitra/' . $dir . '/' . $create_sangmitra_id . '/aadhar_photo/';
            $filenametostore_cover = uploadImage($request, $request_data['file'], $profile_img_path);
            $_SESSION['aadhar_photo'][$filenamewithextension] = $filenametostore_cover;
            return $filenametostore_cover;
        } catch (Exception $e) {
            return response()->json(['icon' => 'error', 'title' => 'Error', 'msg' => $e->getMessage()]);
        }
    }

    /**
     * This function is used to destroy aadhar images
     *
     * @param of image name
     * @return \Illuminate\Http\Response
     */

    public function fileDestroyAadhar(Request $request)
    {
        try {
            session_start();
            // printR($_SESSION);
            $sangmitra_id = $_SESSION['sangmitra_id'];
            $request_data = $request->all();
            $dir = $request_data['dir'];
            $filename = $request->get('filename');
            $path = public_path() . '/assets/images/sangmitra/' . $dir . '/' . $sangmitra_id . '/aadhar_photo/' . $_SESSION['aadhar_photo'][$filename];
            if (file_exists($path)) {
                unlink($path);
            }
            unset($_SESSION['aadhar_photo'][$filename]);
            return $filename;
        } catch (Exception $e) {
            return response()->json(['icon' => 'error', 'title' => 'Error', 'msg' => $e->getMessage()]);
        }
    }

    /**
     * This function is used to upload working docs
     *
     * @param of file in array
     * @return \Illuminate\Http\Response
     */

    public function uploadWorkingDocs(Request $request)
    {
        try {
            session_start();
            $request_data = $request->all();
            $dir = $request_data['dir'];
            //get filename with extension
            $filenamewithextension = $request->file('file')->getClientOriginalName();
            if (empty($_SESSION['sangmitra_id'])) {
                $create_sangmitra_id = 'BOL-' . time();
                $_SESSION['sangmitra_id'] = $create_sangmitra_id;
                $_SESSION['dir'] = $request_data['dir'];
            } else {
                $create_sangmitra_id = $_SESSION['sangmitra_id'];
            }
            $profile_img_path = '/assets/images/sangmitra/' . $dir . '/' . $create_sangmitra_id . '/working_documents/';
            $filenametostore_cover = uploadImage($request, $request_data['file'], $profile_img_path);
            $_SESSION['working_documents'][$filenamewithextension] = $filenametostore_cover;
            return $filenametostore_cover;
        } catch (Exception $e) {
            return response()->json(['icon' => 'error', 'title' => 'Error', 'msg' => $e->getMessage()]);
        }
    }

    /**
     * This function is used to destroy working docs
     *
     * @param of file name
     * @return \Illuminate\Http\Response
     */

    public function fileDestroyWorkingDocs(Request $request)
    {
        try {
            session_start();
            // printR($_SESSION);
            $sangmitra_id = $_SESSION['sangmitra_id'];
            $request_data = $request->all();
            $dir = $request_data['dir'];
            $filename = $request->get('filename');
            $path = public_path() . '/assets/images/sangmitra/' . $dir . '/' . $sangmitra_id . '/working_documents/' . $_SESSION['working_documents'][$filename];
            if (file_exists($path)) {
                unlink($path);
            }
            unset($_SESSION['working_documents'][$filename]);
            return $filename;
        } catch (Exception $e) {
            return response()->json(['icon' => 'error', 'title' => 'Error', 'msg' => $e->getMessage()]);
        }
    }

    /**
     * This function is used to upload working image
     *
     * @param of image in array
     * @return \Illuminate\Http\Response
     */

    public function uploadWorkingPhoto(Request $request)
    {
        try {
            session_start();
            $request_data = $request->all();
            $dir = $request_data['dir'];
            //get filename with extension
            $filenamewithextension = $request->file('file')->getClientOriginalName();
            if (empty($_SESSION['sangmitra_id'])) {
                $create_sangmitra_id = 'BOL-' . time();
                $_SESSION['sangmitra_id'] = $create_sangmitra_id;
                $_SESSION['dir'] = $request_data['dir'];
            } else {
                $create_sangmitra_id = $_SESSION['sangmitra_id'];
            }
            $profile_img_path = '/assets/images/sangmitra/' . $dir . '/' . $create_sangmitra_id . '/work_photos/';
            $filenametostore_cover = uploadImage($request, $request_data['file'], $profile_img_path);
            $_SESSION['work_photos'][$filenamewithextension] = $filenametostore_cover;
            return $filenametostore_cover;
        } catch (Exception $e) {
            return response()->json(['icon' => 'error', 'title' => 'Error', 'msg' => $e->getMessage()]);
        }
    }

    /**
     * This function is used to destroy work images
     *
     * @param of image name
     * @return \Illuminate\Http\Response
     */

    public function fileDestroyWorkingPhoto(Request $request)
    {
        try {
            session_start();
            // printR($_SESSION);
            $sangmitra_id = $_SESSION['sangmitra_id'];
            $request_data = $request->all();
            $dir = $request_data['dir'];
            $filename = $request->get('filename');
            $path = public_path() . '/assets/images/sangmitra/' . $dir . '/' . $sangmitra_id . '/work_photos/' . $_SESSION['work_photos'][$filename];
            if (file_exists($path)) {
                unlink($path);
            }
            unset($_SESSION['work_photos'][$filename]);
            return $filename;
        } catch (Exception $e) {
            return response()->json(['icon' => 'error', 'title' => 'Error', 'msg' => $e->getMessage()]);
        }
    }
}
