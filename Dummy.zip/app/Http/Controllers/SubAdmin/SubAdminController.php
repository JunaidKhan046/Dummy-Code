<?php

namespace App\Http\Controllers\SubAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;

class SubAdminController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:subadmin_dashboard');
        $this->middleware(function ($request, $next) {
            if (empty(Auth::user()->email_verified_at)) {
                Redirect::to('subadmin/email/verify')->send();
            }
            return $next($request);
        });
    }

    /**
     * This function is used to load the vendor home page
     */

    public function index()
    {
        return view('subadmin/home');
    }
}
