<?php

namespace App\Http\Controllers\Admin;

use App\cities;
use App\Http\Controllers\Controller;
use App\service;
use App\states;
use App\sub_service;
use Illuminate\Http\Request;

class CommonController extends Controller
{
    public function getCities(Request $request)
    {
        try {
            $request_data = $request->all();
            $cities = cities::where('state_id', '=', $request_data['state_id'])->get();
            $output = '';
            $output .= '<option value>Select</option>';
            foreach ($cities as $val) {
                $output .= '<option value=' . $val->id . '>' . $val->name . '</option>';
            }
            return response()->json(['cities' => $output]);
        } catch (\Exception $e) {
            return response()->json(['icon' => 'error', 'title' => 'Error', 'msg' => $e->getMessage()]);
        }
    }

    /**
     * This function is used to get state name
     *
     * @param of state id
     * @return response
     */
    public function getStateName(Request $request)
    {
        $request_data = $request->all();
        $id = $request_data['id'];
        $name = states::find($id);
        return response()->json(['stateName' => $name->name]);
    }

    /**
     * This function is used to get city name
     *
     * @param of state id
     * @return response
     */
    public function getCityName(Request $request)
    {
        $request_data = $request->all();
        $id = $request_data['id'];
        $name = cities::find($id);
        return response()->json(['cityName' => $name->name]);
    }

    /**
     * This function is used to get service name
     *
     * @param of state id
     * @return response
     */
    public function getServiceName(Request $request)
    {
        session_start();
        $request_data = $request->all();
        // printR($request_data);
        $id = $request_data['id'];
        $_SESSION['services_id'] = json_encode($id);
        foreach ($id as $val) {
            $name[] = service::find($val);
        }
        for ($i = 0; $i < count($name); $i++) {
            $names[] = $name[$i]->name . ', ';
        }
        // printR($names);
        return response()->json(['serviceName' => $names]);
    }

    /**
     * This function is used to get service name
     *
     * @param of state id
     * @return response
     */
    public function getSubServiceName(Request $request)
    {
        session_start();
        $request_data = $request->all();
        // printR($request_data['id']);
        $id = $request_data['id'];
        $_SESSION['sub_services'] = json_encode($id);
        foreach ($id as $val) {
            $name[] = sub_service::find($val);
        }
        // printR($name);

        for ($i = 0; $i < count($name); $i++) {
            if ($i % 2 == 0) {
                $names[] = $name[$i]->name . ', <br>';
            } else {
                $names[] = $name[$i]->name . ', ';
            }
        }
        // printR($names);
        return response()->json(['subServiceName' => $names]);
    }

    /**
     * This function is used to get service name
     *
     * @param of state id
     * @return response
     */
    public function getDcoument(Request $request)
    {
        session_start();
        // printR($_SESSION);
        if (!empty($_SESSION)) {
            $table = '';
            $table .= '<tr>';
            $table .= '<td align="left" class="text-center" colspan="4"><h4> Documents</span></h4>';
            $table .= '</tr>';
            if (!empty($_SESSION['profile_photo'])) {
                foreach ($_SESSION['profile_photo'] as $val) {
                    $profile_photo = $val;
                }
                $table .= '<tr>';
                $table .= '<td align="left" class="text-center"><span class="fclass">Profile Photo</span></td>';
                $table .= '<td align="center" colspan="3">';
                $table .= '<div style="height:125px; width:135px;   margin:0 auto;">';
                $table .= '<img  src="' . asset('assets/images/sangmitra') . '/' . $_SESSION['dir'] . '/' . $_SESSION['sangmitra_id'] . '/profile_photo/' . $profile_photo . '" align="middle" style="height:125px;width:135px;border-width:0px;" />';
                $table .= '</div>';
                $table .= '</td>';
                $table .= '</tr>';
            }
            if (!empty($_SESSION['aadhar_photo'])) {
                $table .= '<tr>';
                $table .= '<td align="left" class="text-center"><span class="fclass">Aadhar Photo</span></td>';
                $table .= '<td align="center" colspan="3">';
                $table .= '<div style="height:auto; width:135px;   margin:0 auto;">';
                foreach ($_SESSION['aadhar_photo'] as $val) {
                    $table .= '<img  src="' . asset('assets/images/sangmitra') . '/' . $_SESSION['dir'] . '/' . $_SESSION['sangmitra_id'] . '/aadhar_photo/' . $val . '" align="middle" style="height:125px;width:135px;border-width:0px;" />';
                }
                $table .= '</div>';
                $table .= '</td>';
                $table .= '</tr>';
            }
            if (!empty($_SESSION['working_documents'])) {
                $table .= '<tr>';
                $table .= '<td align="left" class="text-center"><span class="fclass">Working Documents</span></td>';
                $table .= '<td align="center" colspan="3">';
                $table .= '<div style="height:auto; width:135px;   margin:0 auto;">';
                $i = 1;
                foreach ($_SESSION['working_documents'] as $val) {
                    $ext = explode('.', $val);
                    if ($i % 2 == 0) {
                        if (end($ext) == 'pdf') {
                            $table .= '<img  src="' . asset('assets/images/index.jpeg') . '" align="middle" style="height:125px;width:135px;border-width:0px; margin:10px" />  <br>';
                        } else if (end($ext) == 'docx') {
                            $table .= '<img  src="' . asset('assets/images/docx-file-14-504256.png') . '" align="middle" style="height:125px;width:135px;border-width:0px; margin:10px" />  <br>';
                        } else {
                            $table .= '<img  src="' . asset('assets/images/sangmitra') . '/' . $_SESSION['dir'] . '/' . $_SESSION['sangmitra_id'] . '/working_documents/' . $val . '" align="middle" style="height:125px;width:135px;border-width:0px; margin:10px" />  <br>';
                        }
                    } else {
                        if (end($ext) == 'pdf') {
                            $table .= '<img  src="' . asset('assets/images/index.jpeg') . '" align="middle" style="height:125px;width:135px;border-width:0px; margin:10px" /> ';
                        } else if (end($ext) == 'docx') {
                            $table .= '<img  src="' . asset('assets/images/docx-file-14-504256.png') . '" align="middle" style="height:125px;width:135px;border-width:0px; margin:10px" /> ';
                        } else {
                            $table .= '<img  src="' . asset('assets/images/sangmitra') . '/' . $_SESSION['dir'] . '/' . $_SESSION['sangmitra_id'] . '/working_documents/' . $val . '" align="middle" style="height:125px;width:135px;border-width:0px; margin:10px" /> ';
                        }
                    }
                    $i++;
                }
                $table .= '</div>';
                $table .= '</td>';
                $table .= '</tr>';
            }
            if (!empty($_SESSION['work_photos'])) {
                $table .= '<tr>';
                $table .= '<td align="left" class="text-center"><span class="fclass">Working Photos</span></td>';
                $table .= '<td align="center" colspan="3">';
                $table .= '<div style="height:auto; width:135px;   margin:0 auto;">';
                $i = 1;
                foreach ($_SESSION['work_photos'] as $val) {
                    if ($i % 2 == 0) {
                        $table .= '<img  src="' . asset('assets/images/sangmitra') . '/' . $_SESSION['dir'] . '/' . $_SESSION['sangmitra_id'] . '/work_photos/' . $val . '" align="middle" style="height:125px;width:135px;border-width:0px; margin:10px" />  <br>';
                    } else {
                        $table .= '<img  src="' . asset('assets/images/sangmitra') . '/' . $_SESSION['dir'] . '/' . $_SESSION['sangmitra_id'] . '/work_photos/' . $val . '" align="middle" style="height:125px;width:135px;border-width:0px; margin:10px" /> ';
                    }
                    $i++;
                }
                $table .= '</div>';
                $table .= '</td>';
                $table .= '</tr>';
            }
            if (!empty($_SESSION['qualification_docs'])) {
                $table .= '<tr>';
                $table .= '<td align="left" class="text-center"><span class="fclass">Qualification Documents</span></td>';
                $table .= '<td align="center" colspan="3">';
                $table .= '<div style="height:auto; width:135px;   margin:0 auto;">';
                $i = 1;
                foreach ($_SESSION['qualification_docs'] as $val) {
                    $ext = explode('.', $val);
                    if ($i % 2 == 0) {
                        if (end($ext) == 'pdf') {
                            $table .= '<img  src="' . asset('assets/images/index.jpeg') . '" align="middle" style="height:125px;width:135px;border-width:0px; margin:10px" />  <br>';
                        } else if (end($ext) == 'docx') {
                            $table .= '<img  src="' . asset('assets/images/docx-file-14-504256.png') . '" align="middle" style="height:125px;width:135px;border-width:0px; margin:10px" />  <br>';
                        } else {
                            $table .= '<img  src="' . asset('assets/images/sangmitra') . '/' . $_SESSION['dir'] . '/' . $_SESSION['sangmitra_id'] . '/qualification_docs/' . $val . '" align="middle" style="height:125px;width:135px;border-width:0px; margin:10px" />  <br>';
                        }
                    } else {
                        if (end($ext) == 'pdf') {
                            $table .= '<img  src="' . asset('assets/images/index.jpeg') . '" align="middle" style="height:125px;width:135px;border-width:0px; margin:10px" /> ';
                        } else if (end($ext) == 'docx') {
                            $table .= '<img  src="' . asset('assets/images/docx-file-14-504256.png') . '" align="middle" style="height:125px;width:135px;border-width:0px; margin:10px" /> ';
                        } else {
                            $table .= '<img  src="' . asset('assets/images/sangmitra') . '/' . $_SESSION['dir'] . '/' . $_SESSION['sangmitra_id'] . '/qualification_docs/' . $val . '" align="middle" style="height:125px;width:135px;border-width:0px; margin:10px" /> ';
                        }
                    }
                    $i++;
                }
                $table .= '</div>';
                $table .= '</td>';
                $table .= '</tr>';
            }
            // echo $table;exit;
            return response()->json(['table' => $table]);
        }
    }
}
