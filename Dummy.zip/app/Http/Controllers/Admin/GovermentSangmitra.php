<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\mitra_common_details;
use App\mitra_gov_priv_emaployee;
use App\states;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Vinkla\Hashids\Facades\Hashids;

class GovermentSangmitra extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('verified');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $result = mitra_gov_priv_emaployee::latest()->where('gov/priv', '=', 1)->paginate();
        return view('admin/sangmitra/index_goverment_sangmitra', compact('result'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        session_start();
        session_unset();
        session_destroy();
        $states = states::where('country_id', '=', 101)->get();
        return view('admin/sangmitra/create_goverment_sangmitra', compact('states'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {
            session_start();
            // session_destroy();exit;
            $request_data = $request->all();
            // printR($_SESSION);
            $validator = Validator::make($request->all(), [
                'services' => 'required',
                'name' => 'required',
                'email' => 'string', 'email', 'max:255', 'unique:mitra_common_details',
                'mobile' => 'required|numeric|digits:10',
                'gender' => 'required',
                'dob' => 'required',
                'father_name' => 'required',
                'state' => 'required',
                'city' => 'required',
                'district' => 'required',
                'pincode' => 'required',
                'aadhar_number' => 'required|numeric|digits:12|unique:mitra_common_details',
                'locality_landmark' => 'required',
                'area_of_department' => 'required',
                'department' => 'required',
                'designation' => 'required',
                'posting_address' => 'required',
            ]);
            if ($validator->fails()) {
                $data = $validator->errors()->toArray();
                foreach ($data as $key => $value) {
                    $message = $value[0];
                    return response()->json(['icon' => 'error', 'title' => 'Please fill required details', 'msg' => $message]);
                    exit;
                }
            } else {
                if (empty($_SESSION['profile_photo'])) {
                    return response()->json(['icon' => 'error', 'title' => 'Please fill required details', 'msg' => 'Please Upload Profile Photo']);
                    exit;
                }
                if (empty($_SESSION['aadhar_photo'])) {
                    return response()->json(['icon' => 'error', 'title' => 'Please fill required details', 'msg' => 'Please Upload Aadhar Photo']);
                    exit;
                }
                $user_id = Auth::user()->id;
                if (empty($_SESSION['sangmitra_id'])) {
                    $create_sangmitra_id = 'BOL-' . time();
                    $_SESSION['sangmitra_id'] = $create_sangmitra_id;
                } else {
                    $create_sangmitra_id = $_SESSION['sangmitra_id'];
                }
                // Seprate mitra common table
                $mitra_common_table = [
                    'sangmitra_id' => $create_sangmitra_id,
                    'aadhar_number' => $request_data['aadhar_number'],
                    'email' => $request_data['email'],
                    'name' => $request_data['name'],
                    'father_name' => $request_data['father_name'],
                    'dob' => $request_data['dob'],
                    'mobile' => $request_data['mobile'],
                    'alternet_mobile' => $request_data['alternet_mobile'],
                    'gender' => $request_data['gender'],
                    'profile_photo' => json_encode($_SESSION['profile_photo']),
                    'state_id' => $request_data['state'],
                    'city_id' => $request_data['city'],
                    'district' => $request_data['district'],
                    'pincode' => $request_data['pincode'],
                    'locality_landmark' => $request_data['locality_landmark'],
                ];
                $insert_id = mitra_common_details::create($mitra_common_table);
                // mitra_busines
                $mitra_govt_table = [
                    'mitra_id' => $insert_id->id,
                    'services' => $request_data['services'],
                    'designation' => $request_data['designation'],
                    'posting_address' => $request_data['posting_address'],
                    'job_description' => $request_data['job_description'],
                    'area_of_department' => $request_data['area_of_department'],
                    'gov/priv' => $request_data['gov/priv'],
                    'department' => $request_data['department'],
                    'aadhar_photo' => json_encode($_SESSION['aadhar_photo']),
                    'working_documents' => json_encode($_SESSION['working_documents']),
                ];
                $insert_id_two = mitra_gov_priv_emaployee::create($mitra_govt_table);
                session_unset();
                session_destroy();
                return response()->json(['icon' => 'success', 'title' => 'Success', 'msg' => 'Data insert or update successfully']);

            }
        } catch (\Exception $e) {
            return response()->json(['icon' => 'error', 'title' => 'Error', 'msg' => $e->getMessage()]);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $id = Hashids::decode($id);
        $result = mitra_gov_priv_emaployee::find($id[0]);
        return view('admin/sangmitra/gov_view', compact('result'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $id = Hashids::decode($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        try {
            $id = Hashids::decode($id);
            $mitra_gov_priv_emaployee = mitra_gov_priv_emaployee::find($id[0]);
            $mitra_gov_priv_emaployee->delete();
            return response()->json(['icon' => 'success', 'title' => 'Success', 'msg' => 'Goverment Sangmitra Delete Successfully !']);
        } catch (\Exception $e) {
            return response()->json(['icon' => 'error', 'title' => 'Error', 'msg' => $e->getMessage()]);
        }
    }
}
