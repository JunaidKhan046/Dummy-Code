<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\service;
use File;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Vinkla\Hashids\Facades\Hashids;

class ServiceController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('verified');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $service = service::latest()->paginate(5);
        return view('admin/services/index', compact('service'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin/services/create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {
            $request_data = $request->all();
            $validator = Validator::make($request->all(), [
                'name' => 'required',
                'image' => 'required|image|mimes:jpeg,png',
                'description' => 'required',
            ]);
            if ($validator->fails()) {
                $data = $validator->errors()->toArray();
                foreach ($data as $key => $value) {
                    $message = $value[0];
                    return response()->json(['icon' => 'error', 'title' => 'Please fill required details', 'msg' => $message]);
                    exit;
                }
            } else {
                $request_data = $request->all();
                $uploadImage = uploadImage($request, $request_data['image'], 'assets/images/services');
                $request_data['image'] = $uploadImage;
                service::create($request_data);
                return response()->json(['icon' => 'success', 'title' => 'Success', 'msg' => 'Service Added Successfully !']);
            }
        } catch (\Exception $e) {
            return response()->json(['icon' => 'error', 'title' => 'Error', 'msg' => $e->getMessage()]);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\service  $service
     * @return \Illuminate\Http\Response
     */
    public function show(service $service)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\service  $service
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        try {
            $id = Hashids::decode($id);
            $service = service::find($id[0]);
            return view('admin/services/edit', compact('service', $service));
        } catch (\Exception $e) {
            return response()->json(['icon' => 'error', 'title' => 'Error', 'msg' => $e->getMessage()]);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\service  $service
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, service $service)
    {
        try {
            $image_name = $request->image_name;
            $image = $request->file('image');
            $request_data = $request->all();
            if ($image != '') {
                $validator = Validator::make($request->all(), [
                    'name' => 'required',
                    'image' => 'required|image|mimes:jpeg,png',
                    'description' => 'required',
                ]);
                if ($validator->fails()) {
                    $data = $validator->errors()->toArray();
                    foreach ($data as $key => $value) {
                        $message = $value[0];
                        return response()->json(['icon' => 'error', 'title' => 'Please fill required details', 'msg' => $message]);
                        exit;
                    }
                } else {
                    $path = public_path() . '/assets/images/services/' . $image_name;
                    if (file_exists($path)) {
                        unlink($path);
                    }
                    $uploadImage = uploadImage($request, $request_data['image'], 'assets/images/services');
                    $request_data['image'] = $uploadImage;
                }
            } else {
                $validator = Validator::make($request->all(), [
                    'name' => 'required',
                    'description' => 'required',
                ]);
                if ($validator->fails()) {
                    $data = $validator->errors()->toArray();
                    foreach ($data as $key => $value) {
                        $message = $value[0];
                        return response()->json(['icon' => 'error', 'title' => 'Please fill required details', 'msg' => $message]);
                        exit;
                    }
                } else {
                    $request_data['image'] = $image_name;
                }
            }
            $service->update($request_data);
            return response()->json(['icon' => 'success', 'title' => 'Success', 'msg' => 'Service Update Successfully !']);
        } catch (\Exception $e) {
            return response()->json(['icon' => 'error', 'title' => 'Error', 'msg' => $e->getMessage()]);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\service  $service
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $id = Hashids::decode($id);
            $service = service::find($id[0]);
            $service->delete();
            return response()->json(['icon' => 'success', 'title' => 'Success', 'msg' => 'Service Delete Successfully !']);
        } catch (\Exception $e) {
            return response()->json(['icon' => 'error', 'title' => 'Error', 'msg' => $e->getMessage()]);
        }

    }

    /**
     * This function is used to active and deactive service status
     *
     * @param id
     * @return success
     */

    public function update_service_status(Request $request)
    {
        try {
            $request_data = $request->all();
            $id = Hashids::decode($request_data['id']);
            $service = service::find($id[0]);
            if ($service->active == true) {
                $service->active = 0;
                $service->save();
                return response()->json(['icon' => 'success', 'title' => 'Success', 'msg' => 'Service Deactive Successfully !']);
                exit;
            } else {
                $service->active = 1;
                $service->save();
                return response()->json(['icon' => 'success', 'title' => 'Success', 'msg' => 'Service Active Successfully !']);
                exit;
            }
        } catch (\Exception $e) {
            return response()->json(['icon' => 'error', 'title' => 'Error', 'msg' => $e->getMessage()]);
        }
    }
}
