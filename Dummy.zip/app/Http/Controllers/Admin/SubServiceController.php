<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\service;
use App\sub_service;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Vinkla\Hashids\Facades\Hashids;

class SubServiceController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('verified');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $sub_service = sub_service::latest()->paginate(5);
        return view('admin/subservice/index', compact('sub_service'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $service = service::where('active', '=', 1)->get();
        return view('admin/subservice/create', compact('service'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'name' => 'required',
                'services_id' => 'required|numeric',
                'description' => 'required',
            ]);
            if ($validator->fails()) {
                $data = $validator->errors()->toArray();
                foreach ($data as $key => $value) {
                    $message = $value[0];
                    return response()->json(['icon' => 'error', 'title' => 'Please fill required details', 'msg' => $message]);
                    exit;
                }
            } else {
                sub_service::create($request->all());
                return response()->json(['icon' => 'success', 'title' => 'Success', 'msg' => 'Sub service Added Successfully !']);
            }
        } catch (\Exception $e) {
            return response()->json(['icon' => 'error', 'title' => 'Error', 'msg' => $e->getMessage()]);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\sub_service  $sub_service
     * @return \Illuminate\Http\Response
     */
    public function show(sub_service $sub_service)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\sub_service  $sub_service
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        try {
            $id = Hashids::decode($id);
            $sub_service = sub_service::find($id[0]);
            $service = service::where('active', '=', 1)->get();
            return view('admin/subservice/edit', compact('sub_service', $sub_service, 'service', $service));
        } catch (\Exception $e) {
            return response()->json(['icon' => 'error', 'title' => 'Error', 'msg' => $e->getMessage()]);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\sub_service  $sub_service
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        try {
            $sub_service = sub_service::find($id);
            $validator = Validator::make($request->all(), [
                'name' => 'required',
                'services_id' => 'required|numeric',
                'description' => 'required',
            ]);
            if ($validator->fails()) {
                $data = $validator->errors()->toArray();
                foreach ($data as $key => $value) {
                    $message = $value[0];
                    return response()->json(['icon' => 'error', 'title' => 'Please fill required details', 'msg' => $message]);
                    exit;
                }
            } else {
                $sub_service->update($request->all());
                return response()->json(['icon' => 'success', 'title' => 'Success', 'msg' => 'Sub service Update Successfully !']);
            }
        } catch (\Exception $e) {
            return response()->json(['icon' => 'error', 'title' => 'Error', 'msg' => $e->getMessage()]);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\sub_service  $sub_service
     * @return \Illuminate\Http\Response
     */
    public function destroy(sub_service $sub_service, $id)
    {
        try {
            $id = Hashids::decode($id);
            $sub_service = sub_service::find($id[0]);
            $sub_service->delete();
            return response()->json(['icon' => 'success', 'title' => 'Success', 'msg' => 'Sub service Delete Successfully !']);
        } catch (\Exception $e) {
            return response()->json(['icon' => 'error', 'title' => 'Error', 'msg' => $e->getMessage()]);
        }
    }

    /**
     * This function is used to active and deactive service status
     *
     * @param id
     * @return success
     */

    public function update_subservice_status(Request $request)
    {
        try {
            $request_data = $request->all();
            $id = Hashids::decode($request_data['id']);
            $service = sub_service::find($id[0]);
            if ($service->active == true) {
                $service->active = 0;
                $service->save();
                return response()->json(['icon' => 'success', 'title' => 'Success', 'msg' => 'Sub service Deactive Successfully !']);
                exit;
            } else {
                $service->active = 1;
                $service->save();
                return response()->json(['icon' => 'success', 'title' => 'Success', 'msg' => 'Sub service Active Successfully !']);
                exit;
            }
        } catch (\Exception $e) {
            return response()->json(['icon' => 'error', 'title' => 'Error', 'msg' => $e->getMessage()]);
        }
    }

}
