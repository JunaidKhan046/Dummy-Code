<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\mitra_common_details;
use App\Notifications\RegisterSubAdmin;
use App\states;
use App\subadmin_dashboard;
use App\subadmin_doc;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Vinkla\Hashids\Facades\Hashids;

class SubAdminController extends Controller
{

    /**4
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('verified');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $result = subadmin_dashboard::latest()->paginate();
        return view('admin/subadmin/index_subadmin', compact('result'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        session_start();
        session_unset();
        session_destroy();
        $states = states::where('country_id', '=', 101)->get();
        return view('admin/subadmin/create_subadmin', compact('states'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {
            session_start();
            // session_destroy();exit;
            $request_data = $request->all();
            // printR($_SESSION);
            $validator = Validator::make($request->all(), [
                'name' => 'required',
                'email' => 'required|string|email|max:255|unique:mitra_common_details',
                'mobile' => 'required|numeric|digits:10',
                'gender' => 'required',
                'dob' => 'required',
                'father_name' => 'required',
                'state' => 'required',
                'city' => 'required',
                'district' => 'required',
                'pincode' => 'required',
                'aadhar_number' => 'required|numeric|digits:12|unique:mitra_common_details',
                'locality_landmark' => 'required',
                'qualification_details' => 'required',
            ]);
            if ($validator->fails()) {
                $data = $validator->errors()->toArray();
                foreach ($data as $key => $value) {
                    $message = $value[0];
                    return response()->json(['icon' => 'error', 'title' => 'Please fill required details', 'msg' => $message]);
                    exit;
                }
            } else {
                if (empty($_SESSION['profile_photo'])) {
                    return response()->json(['icon' => 'error', 'title' => 'Please fill required details', 'msg' => 'Please Upload Profile Photo']);
                    exit;
                }
                if (empty($_SESSION['aadhar_photo'])) {
                    return response()->json(['icon' => 'error', 'title' => 'Please fill required details', 'msg' => 'Please Upload Aadhar Photo']);
                    exit;
                }
                $user_id = Auth::user()->id;
                if (empty($_SESSION['sangmitra_id'])) {
                    $create_sangmitra_id = 'BOL-' . time();
                    $_SESSION['sangmitra_id'] = $create_sangmitra_id;
                } else {
                    $create_sangmitra_id = $_SESSION['sangmitra_id'];
                }
                // Seprate mitra common table
                $mitra_common_table = [
                    'sangmitra_id' => $create_sangmitra_id,
                    'aadhar_number' => $request_data['aadhar_number'],
                    'email' => $request_data['email'],
                    'name' => $request_data['name'],
                    'father_name' => $request_data['father_name'],
                    'dob' => $request_data['dob'],
                    'mobile' => $request_data['mobile'],
                    'alternet_mobile' => $request_data['alternet_mobile'],
                    'gender' => $request_data['gender'],
                    'profile_photo' => json_encode($_SESSION['profile_photo']),
                    'state_id' => $request_data['state'],
                    'city_id' => $request_data['city'],
                    'district' => $request_data['district'],
                    'pincode' => $request_data['pincode'],
                    'locality_landmark' => $request_data['locality_landmark'],
                ];
                // printR($mitra_common_table);
                $insert_id = mitra_common_details::create($mitra_common_table);
                // kalynmitra dashboard
                $subadmin_dashboard = [
                    'subadmin_id' => $insert_id->id,
                    'email' => $request_data['email'],
                    'password' => Hash::make('123456789'),
                ];
                $insert_id_two = subadmin_dashboard::create($subadmin_dashboard);
                // kalyanmitra
                $subadmin_docs = [
                    'subadmin_id' => $insert_id->id,
                    'dashboard_id' => $insert_id_two->id,
                    'qualification_details' => $request_data['qualification_details'],
                    'specification' => $request_data['specification'],
                    'aadhar_card_docs' => json_encode($_SESSION['aadhar_photo']),
                    'qualification_docs' => json_encode($_SESSION['qualification_docs']),
                ];
                // printR($subadmin_docs);
                $insert_id_three = subadmin_doc::create($subadmin_docs);
                // Send notification
                $user = subadmin_dashboard::find($insert_id_two->id);
                $user->notify((new RegisterSubAdmin($mitra_common_table)));
                session_unset();
                session_destroy();
                return response()->json(['icon' => 'success', 'title' => 'Success', 'msg' => 'Data insert or update successfully']);
            }
        } catch (\Exception $e) {
            return response()->json(['icon' => 'error', 'title' => 'Error', 'msg' => $e->getMessage()]);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $id = Hashids::decode($id);
        $result = subadmin_dashboard::find($id[0]);
        // printR($result);
        return view('admin/subadmin/view', compact('result'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $id = Hashids::decode($id);
            $subadmin_dashboard = subadmin_dashboard::find($id[0]);
            $subadmin_dashboard->delete();
            return response()->json(['icon' => 'success', 'title' => 'Success', 'msg' => 'Sub Admin Delete Successfully !']);
        } catch (\Exception $e) {
            return response()->json(['icon' => 'error', 'title' => 'Error', 'msg' => $e->getMessage()]);
        }
    }

    /**
     * This function is used to active and deactive kalynmitra status
     *
     * @param id
     * @return success
     */

    public function update_subadmin_status(Request $request)
    {
        try {
            $request_data = $request->all();
            $id = Hashids::decode($request_data['id']);
            $subadmin_dashboard = subadmin_dashboard::find($id[0]);
            if ($subadmin_dashboard->active == true) {
                $subadmin_dashboard->active = 0;
                $subadmin_dashboard->save();
                return response()->json(['icon' => 'success', 'title' => 'Success', 'msg' => 'Sub Admin Deactive Successfully !']);
                exit;
            } else {
                $subadmin_dashboard->active = 1;
                $subadmin_dashboard->save();
                return response()->json(['icon' => 'success', 'title' => 'Success', 'msg' => 'Sub Admin Active Successfully !']);
                exit;
            }
        } catch (\Exception $e) {
            return response()->json(['icon' => 'error', 'title' => 'Error', 'msg' => $e->getMessage()]);
        }
    }

}
