<?php

/**
 * This Function is used to return the array in user readable format
 *
 * @param $array
 *
 * @return formatted array
 */
function printR($array)
{
    echo "<pre>";
    print_r($array);
    echo "<pre>";
    exit;
}

/**
 * This Function is used to return the array in user readable format
 *
 * @param $array
 *
 * @return formatted array
 */
function printrs($array)
{
    echo "<pre>";
    print_r($array);
    echo "<pre>";
}

/**
 * This function is used to get Yes and No
 *
 * @param of id
 *
 * @return direct name.
 */

function CheckNameStatus($directId)
{
    switch ($directId) {
        case "1":
            $name = "Yes";
            break;
        default:
            $name = "No";
    }
    return $name;
}

/**
 * This function is used to get the building type name
 *
 * @param of id
 *
 * @return building name.
 */

function buildingType($buildingId)
{
    switch ($buildingId) {
        case "1":
            $name = "Gated Society/Apartment";
            break;
        case "2":
            $name = "Independent Builder Floor";
            break;
        default:
            $name = "Independent Kothi";
    }
    return $name;
}

/**
 * This function is used change date format
 *
 * @param of date
 *
 * @return date
 */

function dateFormate($date)
{
    $new_date = date_create($date);
    return date_format($new_date, "d-F-Y");
}

/**
 * This function is used change date format
 *
 * @param of date
 *
 * @return date
 */

function dateFormate2($date)
{
    $new_date = date_create($date);
    return date_format($new_date, "d F Y");
}

/**
 * This function is used change date format on passbook
 *
 * @param of date
 *
 * @return date
 */

function dateFormate3($date)
{
    $new_date = date_create($date);
    return date_format($new_date, "F Y");
}

/**
 * This function is used change date format
 *
 * @param of date
 *
 * @return date
 */

function dateFormate4($date)
{
    $new_date = date_create($date);
    return date_format($new_date, "d/m/Y");
}

/**
 * This function is used change date format
 */

function dateFormate5($date)
{
    $new_date = date_create($date);
    return date_format($new_date, "y-m-d");
}

/**
 * This function is used change date format
 *
 * @param of date
 *
 * @return date
 */

function dateFormate6($date)
{
    $new_date = date_create($date);
    return date_format($new_date, "d-m-Y");
}
/**
 * This function is used to dynamic title
 *
 * @param of page name
 */

function ch_title($title)
{
    $output = ob_get_contents();
    if (ob_get_length() > 0) {
        ob_end_clean();
    }
    $patterns = array("/<title>(.*?)<\/title>/");
    $replacements = array("<title>$title</title>");
    $output = preg_replace($patterns, $replacements, $output);
    echo $output;
}

/**
 * This function is used to get date difference
 *
 * @param of date and current date
 *
 * @return year
 */

function getYear($date1)
{
    $date2 = date("Y-m-d");
    $diff = abs(strtotime($date2) - strtotime($date1));
    $years = floor($diff / (365 * 60 * 60 * 24));
    return $years;
}

/**
 * This Function is used to display Month on the basis of month id.
 *
 * @param $id
 *
 * return months name.
 */
function months($monthId)
{
    switch ($monthId) {
        case "1":
            $month = "January";
            break;
        case "2":
            $month = "February";
            break;
        case "3":
            $month = "Macrh";
            break;
        case "4":
            $month = "April";
            break;
        case "5":
            $month = "May";
            break;
        case "6":
            $month = "June";
            break;
        case "7":
            $month = "July";
            break;
        case "8":
            $month = "August";
            break;
        case "9":
            $month = "September";
            break;
        case "10":
            $month = "October";
            break;
        case "11":
            $month = "November";
            break;
        case "12":
            $month = "December";
            break;
        default:
            $month = "All";
    }
    return $month;
}

/**
 * This function is used to print list of years
 */
function getYearList()
{
    $current_year = date("Y");
    $end_year = '1960';
    for ($i = $current_year; $i >= $end_year; $i--) {
        echo '<option value="' . $i . '">' . $i . '</option>';
    }
}

/**
 * This function is used to print selected list of years
 */
function getYearSelectedList($year)
{
    $current_year = date("Y");
    $end_year = '1960';
    for ($i = $current_year; $i >= $end_year; $i--) {
        if ($i == $year) {
            echo '<option value="' . $i . '" selected>' . $i . '</option>';
        } else {
            echo '<option value="' . $i . '">' . $i . '</option>';
        }
    }
}
/**
 * This function is used two count month
 *
 * @param of two years and month
 *
 * @return total months
 */

function countMonths($to_year, $to_month, $from_year, $from_month)
{
    $diff = (($to_year - $from_year) * 12) + ($to_month - $from_month);
    return $diff;
}

/**
 * This function is used two count days, month and year
 *
 * @param of two years and month
 *
 * @return total days, month and year
 */

function countMonthsWithDays($dates1, $dates2)
{
    $date1 = new DateTime($dates1);
    $date2 = $date1->diff(new DateTime($dates2));
    if ($date2->y > 0) {
        echo $date2->y . ' years' . "\n";
    }
    if ($date2->m > 0) {
        echo $date2->m . ' months' . "\n";
    }
    if ($date2->d > 0) {
        echo $date2->d . ' days' . "\n";
    }
    if ($date2->h > 0) {
        echo $date2->h . ' hours' . "\n";
    }
    if ($date2->i > 0) {
        echo $date2->i . ' minutes' . "\n";
    }
    if ($date2->s > 0) {
        echo $date2->s . ' seconds' . "\n";
    }
}

/**
 * This function is used to get value from stored in json format
 * and check the value is exist or not
 *
 * @param of array format of json
 * @param of value
 *
 * return true and false
 */

function decodeJsonCheckValue($json_array, $value)
{
    $myarray = json_decode($json_array);
    if (in_array($value, $myarray)) {
        echo 'checked';
    }
}

/**
 * This function is used to get differance two date and time
 *
 * @param of two dates
 *
 * @return diff
 */

function my_date_diff($leving_date)
{
    // $current_date = date('Y-m-d H:i:s');
    $date = new DateTime($leving_date);
    $now = new DateTime();
    return $date->diff($now)->format("%m Month, %d Day");
}

/**
 * This function is used to upload documents
 *
 * @param request file name
 * @param directory structure
 *
 * @retur success
 */
function uploadImage($request, $file_name, $directory)
{
    set_time_limit('600');
    //get filename with extension
    $filenamewithextension = $file_name->getClientOriginalName();
    //get filename without extension
    $filename = pathinfo($filenamewithextension, PATHINFO_FILENAME);
    //get file extension
    $extension = $file_name->getClientOriginalExtension();
    //filename to store
    $filenametostore = $filename . '_' . time() . '.' . $extension;
    // create directory
    if (!File::exists($directory)) {
        File::makeDirectory($directory, 0777, true, true);
    }
    //Upload File
    $file_name->move(public_path($directory), $filenametostore);
    return $filenametostore;
}

/**
 * This Function is used to display area of department name.
 *
 * @param $id
 *
 * return Department name.
 */

function area_of_department($department_id)
{
    switch ($department_id) {
        case "1":
            $department = "Central";
            break;
        case "2":
            $department = "State";
            break;
        default:
            $department = "Other";
    }
    return $department;
}

/**
 * This Function is used to display Gender name.
 *
 * @param $id
 *
 * return Gender name.
 */

function gender_name($gender_id)
{
    switch ($gender_id) {
        case "1":
            $gender = "Male";
            break;
        case "2":
            $gender = "Female";
            break;
        default:
            $gender = "Other";
    }
    return $gender;
}

/**
 * This Function is used to display Service name.
 *
 * @param array
 * return services name.
 */

function service_name($array)
{
    $id = json_decode($array);
    foreach ($id as $val) {
        $name[] = App\service::find($val);
    }
    $names = '';
    for ($i = 0; $i < count($name); $i++) {
        $names .= $name[$i]->name . ', ';
    }
    return $names;
}

/**
 * This Function is used to display Service name.
 *
 * @param array
 * return services name.
 */

function sub_service_name($array)
{
    $id = json_decode($array);
    foreach ($id as $val) {
        $name[] = App\sub_service::find($val);
    }
    $names = '';
    for ($i = 0; $i < count($name); $i++) {
        $names .= $name[$i]->name . ', ';
    }
    return $names;
}

/**
 * This function is used to encode website url
 * @param of id
 * @return encoded url
 */

function encodeId($id)
{
    return \Hashids::encode($id); // Used for encoding
}
