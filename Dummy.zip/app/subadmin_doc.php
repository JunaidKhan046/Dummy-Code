<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class subadmin_doc extends Model
{

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'subadmin_id', 'qualification_details', 'aadhar_card_docs', 'qualification_docs', 'specification', 'dashboard_id'];

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
}
