<?php

namespace App;

use App\Notifications\KalyanmitraEmailVerificationNotification;
use App\Notifications\KalyanmitraResetPasswordNotifcation;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class kalyanmitra_dashboard extends Authenticatable implements MustVerifyEmail
{
    use SoftDeletes;
    use Notifiable;
    protected $guard = 'kalyanmitra_dashboard';
    // public $token;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'mitra_id', 'email', 'password'];

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */

    protected $dates = ['deleted_at'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    /**
     * This function is used to reltation ship with common table
     *
     * @param of id
     * @return data
     */

    public function kalyanmitra()
    {
        return $this->belongsTo(mitra_common_details::class, 'mitra_id');
    }

    /**
     * This function is used to reltation ship with kalyanmitra dshboard table
     *
     * @param of id
     * @return data
     */

    public function kalyanmitra_docs()
    {
        return $this->hasMany(kalyanmitra_doc::class, 'dashboard_id');
    }

    /**
     * Send the password reset notification.
     *
     * @param  string  $token
     * @return void
     */
    public function sendPasswordResetNotification($token)
    {
        $this->notify(new KalyanmitraResetPasswordNotifcation($token));
    }

    /**
     * This function is used to send the email verification mail
     */

    public function KalyanmitraEmailVerificationNotification()
    {
        $this->notify(new KalyanmitraEmailVerificationNotification);
    }
}
