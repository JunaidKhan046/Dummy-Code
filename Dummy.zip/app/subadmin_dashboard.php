<?php

namespace App;

use App\Notifications\SubAdminEmailVerificationNotification;
use App\Notifications\SubadminResetPasswordNotifcation;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class subadmin_dashboard extends Authenticatable implements MustVerifyEmail
{
    use SoftDeletes;
    use Notifiable;
    protected $guard = 'subadmin_dashboard';
    // public $token;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'subadmin_id', 'email', 'password'];

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */

    protected $dates = ['deleted_at'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    /**
     * This function is used to reltation ship with common table
     *
     * @param of id
     * @return data
     */

    public function subadmin()
    {
        return $this->belongsTo(mitra_common_details::class, 'subadmin_id');
    }

    /**
     * This function is used to reltation ship with subadmin dshboard table
     *
     * @param of id
     * @return data
     */

    public function subadmin_docs()
    {
        return $this->hasMany(subadmin_doc::class, 'dashboard_id');
    }

    /**
     * Send the password reset notification.
     *
     * @param  string  $token
     * @return void
     */
    public function sendPasswordResetNotification($token)
    {
        $this->notify(new SubadminResetPasswordNotifcation($token));
    }

    /**
     * This function is used to send the email verification mail
     */

    public function SubAdminEmailVerificationNotification()
    {
        $this->notify(new SubAdminEmailVerificationNotification);
    }

}
