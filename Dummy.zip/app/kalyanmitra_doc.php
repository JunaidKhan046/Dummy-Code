<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class kalyanmitra_doc extends Model
{

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'mitra_id', 'qualification_details', 'aadhar_card_docs', 'specification', 'dashboard_id'];

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
}
