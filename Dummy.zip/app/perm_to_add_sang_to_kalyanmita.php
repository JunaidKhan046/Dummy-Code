<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class perm_to_add_sang_to_kalyanmita extends Model
{
    //
}
