<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class mitra_metrimonial extends Model
{
    //
}
