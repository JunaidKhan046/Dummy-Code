<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class mitra_busines extends Model
{
    use SoftDeletes;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'mitra_id', 'services', 'sub_services', 'services_desciption', 'work_name', 'working_address',
        'gst_number', 'aadhar_photo', 'working_documents', 'work_photos'];

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */

    protected $dates = ['deleted_at'];

    /**
     * This function is used to reltation ship with business table
     *
     * @param of id
     * @return data
     */

    public function mitra_busines()
    {
        return $this->belongsTo(mitra_common_details::class, 'mitra_id');
    }
}
