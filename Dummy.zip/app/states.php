<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class states extends Model
{
    protected $fillable = [
        'name', 'country_id'];

    /**
     * This function is used to reltation ship with state table
     *
     * @param of id
     * @return data
     */

    public function states()
    {
        return $this->hasMany(mitra_common_details::class, 'city_id');
    }
}
