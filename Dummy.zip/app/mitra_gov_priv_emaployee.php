<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class mitra_gov_priv_emaployee extends Model
{
    use SoftDeletes;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'services', 'aadhar_photo', 'mitra_id', 'working_documents',
        'area_of_department', 'department', 'designation', 'posting_address', 'job_description', 'gov/priv'];

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */

    protected $dates = ['deleted_at'];

    /**
     * This function is used to reltation ship with business table
     *
     * @param of id
     * @return data
     */

    public function mitra_gov_priv()
    {
        return $this->belongsTo(mitra_common_details::class, 'mitra_id');
    }
}
