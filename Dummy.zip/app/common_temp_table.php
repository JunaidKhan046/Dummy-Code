<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class common_temp_table extends Model
{
    //
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'table_entry_type', 'sangmitra_id', 'aadhar_number', 'email', 'name', 'father_name', 'dob', 'mobile', 'alternet_mobile',
        'gender', 'profile_photo', 'state_id', 'city_id', 'district', 'pincode', 'locality_landmark',
        // Business Table
        'services', 'sub_services', 'services_desciption', 'work_name', 'working_address',
        'gst_number', 'aadhar_photo', 'working_documents', 'work_photos',
        // Gov and Private Table
        'area_of_department', 'department', 'designation', 'posting_address', 'job_description', 'gov/priv', 'active',
        // Unemployed Table
        'qualification', 'higher_qulification_details', 'specification', 'description', 'experience', 'qualification_docs',
        // Metrimonial Table
        'mother_name', 'birth_place', 'time_of_birth', 'job_address', 'photo_gallery', 'height', 'zodiac',
        'color_complexion', 'caste', 'sub_caste', 'gotra',
        // Kalyan Mitra Docs
        'qualification_details', 'aadhar_card_docs',
        // Sub Admmin Docs
        // Added By Flag
        'added_by', 'added_by_id', 'submit_status'];
}
