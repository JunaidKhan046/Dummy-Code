<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class sangmitra_added_by extends Model
{
    //
}
