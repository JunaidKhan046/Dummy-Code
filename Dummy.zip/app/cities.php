<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cities extends Model
{
    protected $fillable = [
        'name', 'state_id'];

    /**
     * This function is used to reltation ship with city table
     *
     * @param of id
     * @return data
     */

    public function cities()
    {
        return $this->hasMany(mitra_common_details::class, 'id');
    }
}
