<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class mitra_common_details extends Model
{
    protected $fillable = [
        'sangmitra_id', 'aadhar_number', 'email', 'name', 'father_name', 'dob', 'mobile', 'alternet_mobile',
        'gender', 'profile_photo', 'state_id', 'city_id', 'district', 'pincode', 'locality_landmark'];

    /**
     * This function is used to reltation ship with business table
     *
     * @param of id
     * @return data
     */

    public function business()
    {
        return $this->hasMany(mitra_busines::class, 'id');
    }

    /**
     * This function is used to reltation ship with goverment table
     *
     * @param of id
     * @return data
     */

    public function gov_privates()
    {
        return $this->hasMany(mitra_gov_priv_emaployee::class, 'id');
    }

    /**
     * This function is used to reltation ship with kalyanmitra dshboard table
     *
     * @param of id
     * @return data
     */

    public function kalyanmitras()
    {
        return $this->hasMany(kalyanmitra_dashboard::class, 'id');
    }

    /**
     * This function is used to reltation ship with state table
     *
     * @param of id
     * @return data
     */

    public function state_mitra_busines()
    {
        return $this->belongsTo(states::class, 'state_id');
    }

    /**
     * This function is used to reltation ship with cities table
     *
     * @param of id
     * @return data
     */

    public function city_mitra_busines()
    {
        return $this->belongsTo(states::class, 'id');
    }

    /**
     * This function is used to reltation ship with subadmin dshboard table
     *
     * @param of id
     * @return data
     */

    public function subadmin()
    {
        return $this->hasMany(subadmin_dashboard::class, 'id');
    }
}
