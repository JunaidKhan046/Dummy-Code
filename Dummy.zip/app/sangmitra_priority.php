<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class sangmitra_priority extends Model
{
    //
}
