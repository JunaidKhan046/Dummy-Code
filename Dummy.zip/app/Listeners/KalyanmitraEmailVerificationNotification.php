<?php

namespace App\Listeners;

use App\Events\KalyanmitraEmailVerification;
use App\Listeners\KalyanmitraEmailVerificationNotification;
use Illuminate\Contracts\Auth\MustVerifyEmail;

class KalyanmitraEmailVerificationNotification
{
    /**
     * Handle the event.
     *
     * @param  KalyanmitraEmailVerification  $event
     * @return void
     */
    public function handle(KalyanmitraEmailVerification $event)
    {
        if ($event->user instanceof MustVerifyEmail && !$event->user->hasVerifiedEmail()) {
            $event->user->KalyanmitraEmailVerificationNotification();
        }
    }
}
