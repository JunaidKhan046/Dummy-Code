<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class perm_to_add_kal_to_subadmin extends Model
{
    //
}
