<!DOCTYPE html>
<html>

<!-- datta-able/bootstrap/default/extra-pages/404/2/index.html /3.x [XR&CO'2014], Sat, 22 Dec 2018 08:22:45 GMT -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
	<meta charset="utf-8">
	<title>404 Dash Able Bootstrap Admin Template</title>
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<link rel="icon" href="{{asset('assets/errors/images/favicon.ico')}}" type="image/x-icon"/>
	<!-- Google font-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="{{asset('assets/errors/css/style.css')}}"/>
</head>
<body>
	<div id="container" class="container">
		<ul id="scene" class="scene">
			<li class="layer" data-depth="1.00"><img src="{{asset('assets/errors/images/404-01.png')}}"></li>
			<li class="layer" data-depth="0.60"><img src="{{asset('assets/errors/images/shadows-01.png')}}"></li>
			<li class="layer" data-depth="0.20"><img src="{{asset('assets/errors/images/monster-01.png')}}"></li>
			<li class="layer" data-depth="0.40"><img src="{{asset('assets/errors/images/text-01.png')}}"></li>
			<li class="layer" data-depth="0.10"><img src="{{asset('assets/errors/images/monster-eyes-01.png')}}"></li>
		</ul>
		<h1>Something Went Wrong !</h1>
    <h2>{{ $exception->getMessage() }}</h2>

		<a href="{{url('/')}}" class="btn">Back to home</a>
	</div>
	<!-- Scripts -->
	<script src="{{asset('assets/errors/js/parallax.js')}}"></script>
	<script>
	// Pretty simple huh?
	var scene = document.getElementById('scene');
	var parallax = new Parallax(scene);
	</script>

</body>

<!-- datta-able/bootstrap/default/extra-pages/404/2/index.html /3.x [XR&CO'2014], Sat, 22 Dec 2018 08:23:01 GMT -->
</html>
