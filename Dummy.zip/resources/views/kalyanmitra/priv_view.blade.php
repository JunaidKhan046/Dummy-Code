

<!DOCTYPE html>
<html lang="en">
   <!-- datta-able/bootstrap/default/ /3.x [XR&CO'2014], Sat, 22 Dec 2018 08:05:37 GMT -->
   <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
   <head>
      <title></title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <meta name="description"
         content="" />
      <meta name="keywords"
         content="">
      <meta name="author" content="Junaid Khan" />
      <meta name="csrf-token" content="{{ csrf_token() }}">
      <meta name="_token" content="{!! csrf_token() !!}" />
      <!-- Favicon icon -->
      <link rel="icon" href="{{asset('assets/images/favicon.ico')}}"
         type="image/x-icon">
      <!-- Latest compiled and minified CSS -->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
      <style>
         a[href]:after{
         display:none;
         }
      </style>
      @include('kalyanmitra/layouts/body')
      <div class="container" id="printTable">
         <div class="row">
            <div class="col-md-12">
               <div class="card-block table-border-style">
                  <div id="div_Data" class="table-responsive">
                     <table class="table" border="2" style="border-collapse: collapse; border-color: Black; background-color: #fff;">
                        <tr>
                           <td colspan="4">
                              <div class="text-center">
                                 <h1>
                                    Mission Bol
                                 </h1>
                              </div>
                              <div class="text-center font-weight-bold">
                                 L-23 R.D.Complex, Sector-3,
                              </div>
                              <div class="text-center font-weight-bold">
                                 Awas Vikas Colony Sikandra, Agra 282001
                              </div>
                           </td>
                        </tr>
                        <tr>
                           <td align="left" class="text-center" colspan="4">
                              <h4> Contact Details</h4>
                           </td>
                        </tr>
                        <tr>
                           <td align="left"><span style="font-family: Arial; font-size:Small; padding-left: 10px; font-style: normal; color:#000000;"> Full Name </span></td>
                           <td align="left" rowspan="1" id="append-name">{{$result->mitra_gov_priv->name}}</td>
                           <td align="left"><span style="font-family: Arial; font-size:Small; padding-left: 10px; font-style: normal; color:#000000;"> Father Name </span></td>
                           <td align="left" id="append-father_name">{{$result->mitra_gov_priv->father_name}}</td>
                        </tr>
                        <tr>
                           <td align = "left"><span style = "font-family: Arial; font-size:Small; padding-left: 10px;  font-style: normal; color:#000000;"> Mobile Number </span></td>
                           <td align = "left" id="append-mobile">{{$result->mitra_gov_priv->mobile}}</td>
                           <td align = "left"><span style = "font-family: Arial; font-size:Small; padding-left: 10px;  font-style: normal; color:#000000;"> Alternet Mobile Number </span></td>
                           <td align = "left" id="append-alternet_mobile">{{$result->mitra_gov_priv->alternet_mobile}}</td>
                        </tr>
                        <tr>
                           <td align="left">
                              <span style="font-family: Arial; font-size:Small; padding-left: 10px; font-style: normal; color:#000000;">Email</span>
                           </td>
                           <td align="left" rowspan="1" id="append-email">
                              {{$result->mitra_gov_priv->email}}
                           </td>
                           <td align="left">
                              <span style="font-family: Arial; font-size:Small; padding-left: 10px; font-style: normal; color:#000000;">DOB</span>
                           </td>
                           <td align="left" rowspan="1" id="append-dob">
                              {{$result->mitra_gov_priv->dob}}
                           </td>
                        </tr>
                        <tr>
                           <td align="left">
                              <span style="font-family: Arial; font-size:Small; padding-left: 10px;  font-style: normal; color:#000000;">Gender</span>
                           </td>
                           <td align="left" id="append-gender">
                              {{gender_name($result->mitra_gov_priv->gender)}}
                           </td>
                           <td align="left">
                              <span style="font-family: Arial; font-size:Small; padding-left: 10px;  font-style: normal; color:#000000;">Aadhaar Number</span>
                           </td>
                           <td align="left" id="append-aadhar_number">
                              {{$result->mitra_gov_priv->aadhar_number}}
                           </td>
                        </tr>
                        <tr>
                           <td align="left">
                              <span style="font-family: Arial; font-size:Small; padding-left: 10px; font-style: normal; color:#000000;">State</span>:</span>
                           </td>
                           <td align="left" id="append-state">
                              {{$result->mitra_gov_priv->state_mitra_busines->name}}
                           </td>
                           <td align="left">
                              <span style="font-family: Arial; font-size:Small; padding-left: 10px; font-style: normal; color:#000000;">
                              City</span>
                           </td>
                           <td align="left" id="append-city-two">
                              {{$result->mitra_gov_priv->city_mitra_busines->name}}
                           </td>
                        </tr>
                        <tr>
                           <td align="left">
                              <span style="font-family: Arial; font-size:Small; padding-left: 10px; font-style: normal; color:#000000;">District</span>:</span>
                           </td>
                           <td align="left" id="append-district">
                              {{$result->mitra_gov_priv->district}}
                           </td>
                           <td align="left">
                              <span style="font-family: Arial; font-size:Small; padding-left: 10px; font-style: normal; color:#000000;">
                              Pincode</span>
                           </td>
                           <td align="left" id="append-pincode">
                              {{$result->mitra_gov_priv->pincode}}
                           </td>
                        </tr>
                        <tr>
                           <td align="left">
                              <span style="font-family: Arial; font-size:Small; padding-left: 10px; font-style: normal; color:#000000;">Landmark / Locality</span>:</span>
                           </td>
                           <td colspan="3" align="left" id="append-locality_landmark">
                              {{$result->mitra_gov_priv->locality_landmark}}
                           </td>
                        </tr>
                        <tr>
                           <td align="left" class="text-center" colspan="4">
                              <h4> Working Details</h4>
                           </td>
                        </tr>
                        <tr>

                            <td align="left">
                                <span style="font-family: Arial; font-size:Small; padding-left: 10px; font-style: normal; color:#000000;">
                                Department</span>
                            </td>
                            <td align="left" id="append-department">
                            {{$result->department}}
                            </td>
                            <td align="left"><span style="font-family: Arial; padding-left: 10px;  font-size:Small; font-style: normal; color:#000000;">Designation</span></td>
                            <td align="left" id="append-designation">
                            {{$result->designation}}
                            </td>
                        </tr>
                        <tr>

                            <td align="left">
                                <span style="font-family: Arial; font-size:Small; padding-left: 10px; font-style: normal; color:#000000;">
                                Posting Address</span>
                            </td>
                            <td colspan="3" align="left" id="append-posting_address">
                            {{$result->posting_address}}
                            </td>
                        </tr>
                        <tr>
                            <td align="left">
                                <span style="font-family: Arial; font-size:Small; padding-left: 10px; font-style: normal; color:#000000;"> Job Description</span>
                            </td>
                            <td colspan="3" align="left" id="append-job_description">
                            {{$result->job_description}}
                            </td>
                        </tr>
                        <tr>
                           <td class="text-center" colspan="4" align="left">
                              <h4> Documents</h4>
                           </td>
                        </tr>
                        <tr>
                           <td class="text-center" align="left"><span class="fclass">Profile Photo</span></td>
                           <td colspan="3" align="center">
                              <div style="height:125px; width:135px; margin:0 auto;">
                                 @php
                                 $profile_photo = json_decode($result->mitra_gov_priv->profile_photo);
                                 @endphp
                                 @foreach($profile_photo as $val)
                                 @php $profile_photo = $val; @endphp
                                 @endforeach
                                 <a href="{{asset('assets/images/sangmitra/private')}}/{{$result->mitra_gov_priv->sangmitra_id}}/profile_photo/{{$profile_photo}}" target="_blank">
                                 <img src="{{asset('assets/images/sangmitra/private')}}/{{$result->mitra_gov_priv->sangmitra_id}}/profile_photo/{{$profile_photo}}" style="height:125px;width:135px;border-width:0px;" align="middle"></a>
                              </div>
                           </td>
                        </tr>
                        <tr>
                           <td class="text-center" align="left"><span class="fclass">Aadhar Photo</span></td>
                           <td colspan="3" align="center">
                              @php
                              $aadhar_photo = json_decode($result->aadhar_photo);
                              @endphp
                              <div style="height:auto; width:135px;   margin:0 auto;">
                              @foreach($aadhar_photo as $val)
                                 <a href="{{asset('assets/images/sangmitra/private')}}/{{$result->mitra_gov_priv->sangmitra_id}}/aadhar_photo/{{$val}}" target="_blank">
                                 <img src="{{asset('assets/images/sangmitra/private')}}/{{$result->mitra_gov_priv->sangmitra_id}}/aadhar_photo/{{$val}}" style="height:125px;width:135px;border-width:0px; margin:10px" align="middle"></a><br>
                              @endforeach
                              </div>
                           </td>
                        </tr>
                        @if(!empty($result->working_documents))
                        @php
                        $working_documents = json_decode($result->working_documents);
                        @endphp
                        <tr>
                           <td class="text-center" align="left"><span class="fclass">Working Documents</span></td>
                           <td colspan="3" align="center">
                              <div style="height:auto; width:135px;   margin:0 auto;">
                                 @foreach($working_documents as $val)
                                 @php $ext = explode('.', $val); @endphp
                                 @if (end($ext) == 'docx')
                                 <a href="{{asset('assets/images/sangmitra/private')}}/{{$result->mitra_gov_priv->sangmitra_id}}/working_documents/{{$val}}" target="_blank">
                                 <img src="{{asset('assets/images/docx-file-14-504256.png')}}" style="height:125px;width:135px;border-width:0px; margin:10px" align="middle">
                                 </a>
                                 @elseif(end($ext) == 'pdf')
                                 <a href="{{asset('assets/images/sangmitra/private')}}/{{$result->mitra_gov_priv->sangmitra_id}}/working_documents/{{$val}}" target="_blank">
                                 <img src="{{asset('assets/images/index.jpeg')}}" style="height:125px;width:135px;border-width:0px; margin:10px" align="middle">
                                 </a>
                                 @else
                                 <a href="{{asset('assets/images/sangmitra/private')}}/{{$result->mitra_gov_priv->sangmitra_id}}/working_documents/{{$val}}" target="_blank">
                                 <img src="{{asset('assets/images/sangmitra/private')}}/{{$result->mitra_gov_priv->sangmitra_id}}/working_documents/{{$val}}" style="height:125px;width:135px;border-width:0px; margin:10px" align="middle">
                                 </a>
                                 @endif
                                 @endforeach
                              </div>
                           </td>
                        </tr>
                        @endif
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="row text-center">
         <div class="col-sm-12 invoice-btn-group text-center">
            <button type="button" class="btn btn-primary btn-print-invoice m-b-10">Print</button>
         </div>
      </div>
      @include('kalyanmitra/layouts/footer')
      <script>
         // print button
             function printData() {
                 var divToPrint = document.getElementById("printTable");
                 newWin = window.open("");
                 newWin.document.write(divToPrint.outerHTML);
                 newWin.print();
                 newWin.close();
             }

             $('.btn-print-invoice').on('click', function() {
                //  printData();
                window.print();
             })

      </script>
      @include('kalyanmitra/layouts/footer_end')
      {{ch_title('Mission Bol || View Private Sangmitra')}}
