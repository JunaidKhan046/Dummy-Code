@include('kalyanmitra/layouts/head')
      <div class="auth-wrapper aut-bg-img">
         <div class="auth-content">
            <form method="POST" action="{{ route('kalyanmitra.password.update') }}">
               @csrf
               <input type="hidden" name="token" value="{{ $token }}">
               <div class="card">
                  <div class="card-body text-center">
                     <div class="mb-4">
                        <i class="feather icon-unlock auth-icon"></i>
                     </div>
                     <h3 class="mb-4">{{ __('Reset Password') }}</h3>
                     <div class="input-group mb-3">
                        <input type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus placeholder="Email">
                        @error('email')
                        <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                     </div>
                     <div class="input-group mb-4">
                        <input type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="current-password"  placeholder="password">
                        @error('password')
                        <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                     </div>
                     <div class="input-group mb-4">
                        <input type="password" class="form-control" name="password_confirmation" required autocomplete="new-password" placeholder="confirm password">
                     </div>
                     <button type="submit" class="btn btn-primary shadow-2 mb-4">{{ __('Reset Password') }}</button>
                  </div>
               </div>
            </form>
         </div>
      </div>
      @include('kalyanmitra/layouts/footer')
    @include('kalyanmitra/layouts/footer_end')
    {{ch_title('Mission Bol Kalyamitra Change Password')}}
