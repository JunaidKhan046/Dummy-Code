
@include('kalyanmitra/layouts/head')
<style>
  .g-recaptcha{border:none!important;
            margin-left: -20px!important;
        }
</style>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>

      <div class="auth-wrapper aut-bg-img">
         <div class="auth-content">
            <form method="POST" action="{{ route('kalyanmitra.login') }}" id="form">
               @csrf
               <div class="card">
                  <div class="card-body text-center">
                     <div class="mb-4">
                        <i class="feather icon-unlock auth-icon"></i>
                     </div>
                     <h3 class="mb-4">Kalyanmitra Login</h3>
                     <div class="input-group mb-3">
                        <input type="email" class="form-control {{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus placeholder="Email">
                        @if ($errors->has('email'))
                              <span class="invalid-feedback" role="alert">
                              <strong>{{ $errors->first('email')}}</strong>
                              </span>
                              @endif
                     </div>
                     <div class="input-group mb-4">
                        <input type="password" class="form-control {{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" required autocomplete="current-password"  placeholder="password">
                        @if ($errors->has('password'))
                              <span class="invalid-feedback" role="alert">
                              <strong>{{ $errors->first('password')}}</strong>
                              </span>
                              @endif
                     </div>
                     <div class="form-group text-left">
                        <div class="checkbox checkbox-fill d-inline">
                           <input type="checkbox" name="remember" id="checkbox-fill-a1" {{ old('remember') ? 'checked' : '' }}>
                           <label for="checkbox-fill-a1" class="cr">{{ __('Remember Me') }}</label>
                        </div>
                     </div>
                     <div class="form-group">
                        <div class="row">
                            <div class="col-sm-12 col-sm-offset-3">
                            <div class="form-group row mb-0">
                                <div class="col-sm-12 col-sm-offset-3">
                                    <div class="g-recaptcha form-control {{ $errors->has('g-recaptcha-response') ? ' is-invalid' : '' }}" data-sitekey="6LcPuhIUAAAAAK8liWPQ9_i3jAzZdwOC-05tpTrb"></div>
                                    @if ($errors->has('g-recaptcha-response'))
                                    <span class="invalid-feedback" role="alert">
                                    <strong>{{ $errors->first('g-recaptcha-response') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                        </div>
                    </div>

                     <button type="submit" class="btn btn-primary shadow-2 mb-4">{{ __('Login') }}</button>
                     <p class="mb-2 text-muted">Forgot password?
                        @if (Route::has('kalyanmitra.password.update'))
                        <a href="{{ route('kalyanmitra.password.update') }}">{{ __('Reset') }}</a>
                        @endif
                     </p>
                  </div>
               </div>

            </form>
         </div>
      </div>

      @include('kalyanmitra/layouts/footer')
      <script>
      $(function(){
         $('#form').submit(function (event){
            var verified = grecaptcha.getResponse();
            if(verified.length === 0){
               event.preventDefault();
            }
         });
      });
      </script>
    @include('kalyanmitra/layouts/footer_end')
    {{ch_title('Mission Bol Kalyanmitra Signin')}}
