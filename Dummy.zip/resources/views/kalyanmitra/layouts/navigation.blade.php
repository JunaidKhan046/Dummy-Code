
@php
$url = explode('/', url()->current());
$prev = $url[count($url)-2];
@endphp
    <!-- [ navigation menu ] start -->
    <nav class="pcoded-navbar navbar-image-5 brand-dark drp-icon-style2 menu-item-icon-style6 caption-hide">
        <div class="navbar-wrapper">
            <div class="navbar-brand header-logo">
                <a href="{{url('kalyanmitra/home')}}" class="b-brand">
                    <div class="b-bg">
                        <i class="feather icon-trending-up"></i>
                    </div>
                    <span class="b-title">Mission Bol</span>
                </a>
                <a class="mobile-menu" id="mobile-collapse" href="#!"><span></span></a>
            </div>
            <div class="navbar-content scroll-div">
                <ul class="nav pcoded-inner-navbar">
                @if(end($url) == 'home')
                    <li data-username="dashboard" class="nav-item active pcoded-trigger">
                        <a href="{{url('kalyanmitra/home')}}" class="nav-link"><span class="pcoded-micon">
                        <i class="feather icon-home"></i></span><span class="pcoded-mtext">Dashboard</span></a>
                    </li>
                    @else
                    <li data-username="dashboard" class="nav-item">
                        <a href="{{url('kalyanmitra/home')}}" class="nav-link"><span class="pcoded-micon">
                        <i class="feather icon-home"></i></span><span class="pcoded-mtext">Dashboard</span></a>
                    </li>
                    @endif
                    @if($prev.'/'.end($url) == 'business_sangmitra/create' || end($url) == 'business_sangmitra' || $prev.'/'.end($url) == 'goverment_sangmitra/create'
                    || end($url) == 'goverment_sangmitra' || $prev.'/'.end($url) == 'private_sangmitra/create' || end($url) == 'private_sangmitra' )
                    <li data-username="sangmitra" class="nav-item pcoded-hasmenu active pcoded-trigger">
                        <a href="#!" class="nav-link"><span class="pcoded-micon">
                        <i class="fas fa-users"></i></span><span class="pcoded-mtext">Sangmitra</span></a>
                        <ul class="pcoded-submenu">
                            <li class="{{end($url) == 'business_sangmitra' ? 'active' : ''}}"><a href="{{url('kalyanmitra/business_sangmitra')}}" class="">Business Sangmitra</a></li>
                            <li class="{{$prev.'/'.end($url) == 'business_sangmitra/create' ? 'active' : ''}}"><a href="{{url('kalyanmitra/business_sangmitra/create')}}" class="">Add Business Snngmitra</a></li>
                            <li class="{{end($url) == 'goverment_sangmitra' ? 'active' : ''}}"><a href="{{url('kalyanmitra/goverment_sangmitra')}}" class="">Goverment Sangmitra</a></li>
                            <li class="{{$prev.'/'.end($url) == 'goverment_sangmitra/create' ? 'active' : ''}}"><a href="{{url('kalyanmitra/goverment_sangmitra/create')}}" class="">Add Goverment Sangmitra</a></li>
                            <li class="{{end($url) == 'private_sangmitra' ? 'active' : ''}}"><a href="{{url('kalyanmitra/private_sangmitra')}}" class="">Private Sangmitra</a></li>
                            <li class="{{$prev.'/'.end($url) == 'private_sangmitra/create' ? 'active' : ''}}"><a href="{{url('kalyanmitra/private_sangmitra/create')}}">Add Private Sangmitra</a></li>
                            <!-- <li class=""><a href="bc_alert.html" class="">Unemployed Sangmitra</a></li>
                            <li class=""><a href="bc_button.html" class="">Add Unemployed Sangmitra</a></li>
                            <li class=""><a href="bc_alert.html" class="">Matrimonial Sangmitra</a></li>
                            <li class=""><a href="bc_button.html" class="">Add Matrimonial Sangmitra</a></li> -->
                        </ul>
                    </li>
                    @else
                    <li data-username="sangmitra" class="nav-item pcoded-hasmenu">
                        <a href="#!" class="nav-link"><span class="pcoded-micon">
                        <i class="fas fa-users"></i></span><span class="pcoded-mtext">Sangmitra</span></a>
                        <ul class="pcoded-submenu">
                            <li class=""><a href="{{url('kalyanmitra/business_sangmitra')}}" class="">Business Sangmitra</a></li>
                            <li class=""><a href="{{url('kalyanmitra/business_sangmitra/create')}}" class="">Add Business Snngmitra</a></li>
                            <li class=""><a href="{{url('kalyanmitra/goverment_sangmitra')}}" class="">Goverment Sangmitra</a></li>
                            <li class=""><a href="{{url('kalyanmitra/goverment_sangmitra/create')}}" class="">Add Goverment Sangmitra</a></li>
                            <li class=""><a href="{{url('kalyanmitra/private_sangmitra')}}" class="">Private Sangmitra</a></li>
                            <li class=""><a href="{{url('kalyanmitra/private_sangmitra/create')}}" class="">Add Private Sangmitra</a></li>
                            <!-- <li class=""><a href="bc_alert.html" class="">Unemployed Sangmitra</a></li>
                            <li class=""><a href="bc_button.html" class="">Add Unemployed Sangmitra</a></li>
                            <li class=""><a href="bc_alert.html" class="">Matrimonial Sangmitra</a></li>
                            <li class=""><a href="bc_button.html" class="">Add Matrimonial Sangmitra</a></li> -->
                        </ul>
                    </li>
                    @endif
                </ul>
            </div>
        </div>
    </nav>
    <!-- [ navigation menu ] end -->
