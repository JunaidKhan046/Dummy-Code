
@include('kalyanmitra/layouts/head')
      <div class="auth-wrapper aut-bg-img">
         <div class="auth-content">
            <form method="POST" action="{{ route('kalyanmitra.password.email') }}">
               @csrf
               <div class="card">
                  <div class="card-body text-center">
                     <div class="mb-4">
                        <i class="feather icon-mail auth-icon"></i>
                     </div>
                     <h3 class="mb-4">Reset Password</h3>
                     @if (session('status'))
                     <div class="alert alert-success" role="alert">
                        {{ session('status') }}
                     </div>
                     @endif
                     <div class="input-group mb-3">
                        <input type="email" class="form-control @error('email') is-invalid @enderror" placeholder="Email" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>
                        @error('email')
                        <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                     </div>
                     <button  type="submit" class="btn btn-primary mb-4 shadow-2">
                     {{ __('Send Password Reset Link') }}
                     </button>
                  </div>
               </div>
            </form>
         </div>
      </div>
      @include('kalyanmitra/layouts/footer')
    @include('kalyanmitra/layouts/footer_end')
    {{ch_title('Mission Bol Kalyanmitra Reset Password')}}
