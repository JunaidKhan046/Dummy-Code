<div class="usermsg_container" style="max-width: 600px;margin: 0 auto;border-right: 1px solid #ccc;font-family: sans-serif;border-left: 1px solid #ccc;border-top: 1px solid #ccc;">
    <div style="padding: 30px;">
        <div class="em-navbar" style="display: flex; border-bottom: 1px dotted #ccc; padding-bottom: 20px;  position: relative;">
            <div class="logo" style="width: 80%;">
                <img src="https://missionbol.com/assets/ico/logo.png" style=" max-width: 215px; ">
                <span style="color:#0067ac; font-wieght:900; margin-top:0px; font-size:24px;"><strong>Mission </strong></span><span style="color:#e95615; font-wieght:900; margin-top:0px; font-size:24px;">Bol</span>
            </div>
            <div class="social" style="width: 18%;">
                <ul style="display: flex;">
                    <li style="list-style: none;margin: 0 3px;">
                        <a href="#">
                            <img src="http://maredo.dev.auswide.services/wp-content/uploads/2017/09/fb-email.png">
                        </a>
                    </li>
                    <li style="list-style: none;margin: 0 3px;">
                        <a href="#">
                            <img src="http://maredo.dev.auswide.services/wp-content/uploads/2017/09/insta-email.png">
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="em-body">
            <h3 style="font-size: 20px; font-weight: 100; text-align:center;">Reset Password </h3>
            <h2 style="font-size: 18px; fon-weight:100; text-align:center;">Please click the button below to reset your password.</h2>
            <center><a style="display: block; width: 200px; height: 25px;  background: #0067ac; padding: 10px; text-align: center; border-radius: 5px; color: #fff; font-weight: bold; text-decoration:none;" href="{{route('subadmin.password.reset', $url)}}">Reset Password</a></center>
            <p>
            If you did not reset your password your account, no further action is required.
            <br>
                Thank you,<br>
                <a href="https://missionbol.com/front-end" target="_blank" style="text-decoration: none;">Mission Bol</a>
            </p>
        </div>

    </div>
    <div class="bottom-footer" style="background: linear-gradient(90deg,#252c78,#0c0a8f);padding: 20px 0;">
        <div style="
             display: flex;
             text-align: center;
             box-sizing: border-box;
             font-size: 12px;
             ">
            <a href="tel:+91 9368093745" style="
	         width: 33%;
	         color: #fff;
	         ">+91 9368093745</a>
            <a href="https://missionbol.com/front-end" style="
               width: 33%;
               color: #fff;
               " target="_blank">www.missionbol.com</a>
        </div>
        <div>
            <p style="
               font-size: 12px;
               text-align: center;
               margin: 5px 0;
               color: #fff;
               ">
                L-23 R.D.Complex, Sector-3,
                Awas Vikas Colony Sikandra,
                Agra 282001
            </p>
        </div>
        <div>
            <p style="
               font-size: 12px;
               text-align: center;
               color: #fff;
               margin: 5px 0;
               ">
                2018 © Computer Hardware Expert | All rights reserved.
            </p>
        </div>
    </div>
</div>
