
@php
$url = explode('/', url()->current());
$prev = $url[count($url)-2];
@endphp
    <!-- [ navigation menu ] start -->
    <nav class="pcoded-navbar navbar-image-5 brand-dark drp-icon-style2 menu-item-icon-style6 caption-hide">
        <div class="navbar-wrapper">
            <div class="navbar-brand header-logo">
                <a href="{{url('admin/home')}}" class="b-brand">
                    <div class="b-bg">
                        <i class="feather icon-trending-up"></i>
                    </div>
                    <span class="b-title">Mission Bol</span>
                </a>
                <a class="mobile-menu" id="mobile-collapse" href="#!"><span></span></a>
            </div>
            <div class="navbar-content scroll-div">
                <ul class="nav pcoded-inner-navbar">
                @if(end($url) == 'home')
                    <li data-username="dashboard" class="nav-item active pcoded-trigger">
                        <a href="{{url('admin/home')}}" class="nav-link"><span class="pcoded-micon">
                        <i class="feather icon-home"></i></span><span class="pcoded-mtext">Dashboard</span></a>
                    </li>
                    @else
                    <li data-username="dashboard" class="nav-item">
                        <a href="{{url('admin/home')}}" class="nav-link"><span class="pcoded-micon">
                        <i class="feather icon-home"></i></span><span class="pcoded-mtext">Dashboard</span></a>
                    </li>
                    @endif
                    @if($prev.'/'.end($url) == 'business_sangmitra/create' || end($url) == 'business_sangmitra' || $prev.'/'.end($url) == 'goverment_sangmitra/create'
                    || end($url) == 'goverment_sangmitra' || $prev.'/'.end($url) == 'private_sangmitra/create' || end($url) == 'private_sangmitra' )
                    <li data-username="sangmitra" class="nav-item pcoded-hasmenu active pcoded-trigger">
                        <a href="#!" class="nav-link"><span class="pcoded-micon">
                        <i class="fas fa-users"></i></span><span class="pcoded-mtext">Sangmitra</span></a>
                        <ul class="pcoded-submenu">
                            <li class="{{end($url) == 'business_sangmitra' ? 'active' : ''}}"><a href="{{url('admin/business_sangmitra')}}" class="">Business Sangmitra</a></li>
                            <li class="{{$prev.'/'.end($url) == 'business_sangmitra/create' ? 'active' : ''}}"><a href="{{url('admin/business_sangmitra/create')}}" class="">Add Business Snngmitra</a></li>
                            <li class="{{end($url) == 'goverment_sangmitra' ? 'active' : ''}}"><a href="{{url('admin/goverment_sangmitra')}}" class="">Goverment Sangmitra</a></li>
                            <li class="{{$prev.'/'.end($url) == 'goverment_sangmitra/create' ? 'active' : ''}}"><a href="{{url('admin/goverment_sangmitra/create')}}" class="">Add Goverment Sangmitra</a></li>
                            <li class="{{end($url) == 'private_sangmitra' ? 'active' : ''}}"><a href="{{url('admin/private_sangmitra')}}" class="">Private Sangmitra</a></li>
                            <li class="{{$prev.'/'.end($url) == 'private_sangmitra/create' ? 'active' : ''}}"><a href="{{url('admin/private_sangmitra/create')}}">Add Private Sangmitra</a></li>
                            <!-- <li class=""><a href="bc_alert.html" class="">Unemployed Sangmitra</a></li>
                            <li class=""><a href="bc_button.html" class="">Add Unemployed Sangmitra</a></li>
                            <li class=""><a href="bc_alert.html" class="">Matrimonial Sangmitra</a></li>
                            <li class=""><a href="bc_button.html" class="">Add Matrimonial Sangmitra</a></li> -->
                        </ul>
                    </li>
                    @else
                    <li data-username="sangmitra" class="nav-item pcoded-hasmenu">
                        <a href="#!" class="nav-link"><span class="pcoded-micon">
                        <i class="fas fa-users"></i></span><span class="pcoded-mtext">Sangmitra</span></a>
                        <ul class="pcoded-submenu">
                            <li class=""><a href="{{url('admin/business_sangmitra')}}" class="">Business Sangmitra</a></li>
                            <li class=""><a href="{{url('admin/business_sangmitra/create')}}" class="">Add Business Snngmitra</a></li>
                            <li class=""><a href="{{url('admin/goverment_sangmitra')}}" class="">Goverment Sangmitra</a></li>
                            <li class=""><a href="{{url('admin/goverment_sangmitra/create')}}" class="">Add Goverment Sangmitra</a></li>
                            <li class=""><a href="{{url('admin/private_sangmitra')}}" class="">Private Sangmitra</a></li>
                            <li class=""><a href="{{url('admin/private_sangmitra/create')}}" class="">Add Private Sangmitra</a></li>
                            <!-- <li class=""><a href="bc_alert.html" class="">Unemployed Sangmitra</a></li>
                            <li class=""><a href="bc_button.html" class="">Add Unemployed Sangmitra</a></li>
                            <li class=""><a href="bc_alert.html" class="">Matrimonial Sangmitra</a></li>
                            <li class=""><a href="bc_button.html" class="">Add Matrimonial Sangmitra</a></li> -->
                        </ul>
                    </li>
                    @endif
                    @if($prev.'/'.end($url) == 'kalyanmitra/create' || end($url) == 'kalyanmitra')
                    <li data-username="kalyanmitra"
                        class="nav-item pcoded-hasmenu active pcoded-trigger">
                        <a href="#!" class="nav-link"><span class="pcoded-micon"><i
                                    class="fas fa-user-tie"></i></span><span class="pcoded-mtext">Kalyanmitra</span></a>
                        <ul class="pcoded-submenu">
                            <li class="{{end($url) == 'kalyanmitra' ? 'active' : ''}}"><a href="{{url('admin/kalyanmitra')}}" class="">Kalyanmitra</a></li>
                            <li class="{{$prev.'/'.end($url) == 'kalyanmitra/create' ? 'active' : ''}}"><a href="{{url('admin/kalyanmitra/create')}}" class="">Add Kalyanmitra</a></li>
                        </ul>
                    </li>
                    @else
                    <li data-username="kalyanmitra"
                        class="nav-item pcoded-hasmenu">
                        <a href="#!" class="nav-link"><span class="pcoded-micon"><i
                                    class="fas fa-user-tie"></i></span><span class="pcoded-mtext">Kalyanmitra</span></a>
                        <ul class="pcoded-submenu">
                            <li class="{{end($url) == 'kalyanmitra' ? 'active' : ''}}"><a href="{{url('admin/kalyanmitra')}}" class="">Kalyanmitra</a></li>
                            <li class=""><a href="{{url('admin/kalyanmitra/create')}}" class="">Add Kalyanmitra</a></li>
                        </ul>
                    </li>
                    @endif
                    @if($prev.'/'.end($url) == 'subadmin/create' || end($url) == 'subadmin')
                    <li data-username="subadmin"
                    class="nav-item pcoded-hasmenu active pcoded-trigger">
                        <a href="#!" class="nav-link"><span class="pcoded-micon"><i
                                    class="fas fa-user-graduate"></i></span><span class="pcoded-mtext">Sub Admin</span></a>
                        <ul class="pcoded-submenu">
                            <li class="{{end($url) == 'subadmin' ? 'active' : ''}}"><a href="{{url('admin/subadmin')}}" class="">Sub Admin</a></li>
                            <li class="{{$prev.'/'.end($url) == 'subadmin/create' ? 'active' : ''}}"><a href="{{url('admin/subadmin/create')}}" class="">Add Sub Admin</a></li>
                        </ul>
                    </li>
                    @else
                    <li data-username="subadmin"
                        class="nav-item pcoded-hasmenu">
                        <a href="#!" class="nav-link"><span class="pcoded-micon"><i
                                    class="fas fa-user-graduate"></i></span><span class="pcoded-mtext">Sub Admin</span></a>
                        <ul class="pcoded-submenu">
                            <li class=""><a href="{{url('admin/subadmin')}}" class="">Sub Admin</a></li>
                            <li class=""><a href="{{url('admin/subadmin/create')}}" class="">Add Sub Admin</a></li>
                        </ul>
                    </li>
                    @endif
                @if(end($url) == 'service' || $prev.'/'.end($url) == 'service/create')
                    <li data-username="services"
                        class="nav-item pcoded-hasmenu active pcoded-trigger">
                        <a href="#!" class="nav-link"><span class="pcoded-micon"><i
                                    class="fas fa-cog"></i></span><span
                                class="pcoded-mtext">Services</span></a>
                        <ul class="pcoded-submenu">
                            <li class="{{end($url) == 'service' ? 'active' : ''}}"><a href="{{url('admin/service')}}" class="">Services</a></li>
                            <li class="{{end($url) == 'create' ? 'active' : ''}}"><a href="{{url('admin/service/create')}}" class="">Add Services</a></li>
                        </ul>
                    </li>
                    @else
                    <li data-username="services"
                        class="nav-item pcoded-hasmenu">
                        <a href="#!" class="nav-link"><span class="pcoded-micon"><i
                                    class="fas fa-cog"></i></span><span
                                class="pcoded-mtext">Services</span></a>
                        <ul class="pcoded-submenu">
                            <li class=""><a href="{{url('admin/service')}}" class="">Services</a></li>
                            <li class=""><a href="{{url('admin/service/create')}}" class="">Add Services</a></li>
                        </ul>
                    </li>
                    @endif
                    @if(end($url) == 'subservice' || $prev.'/'.end($url) == 'subservice/create')
                    <li data-username="subservices"
                        class="nav-item pcoded-hasmenu active pcoded-trigger">
                        <a href="#!" class="nav-link"><span class="pcoded-micon"><i
                                    class="fas fa-cogs"></i></span><span
                                class="pcoded-mtext">Sub Services</span></a>
                        <ul class="pcoded-submenu">
                            <li class="{{end($url) == 'subservice' ? 'active' : ''}}"><a href="{{url('admin/subservice')}}" class="">Sub Services</a></li>
                            <li class="{{$prev.'/'.end($url) == 'subservice/create' ? 'active' : ''}}"><a href="{{url('admin/subservice/create')}}" class="">Add Sub Services</a></li>
                        </ul>
                    </li>
                    @else
                    <li data-username="subservices"
                        class="nav-item pcoded-hasmenu">
                        <a href="#!" class="nav-link"><span class="pcoded-micon"><i
                                    class="fas fa-cogs"></i></span><span
                                class="pcoded-mtext">Sub Services</span></a>
                        <ul class="pcoded-submenu">
                            <li class=""><a href="{{url('admin/subservice')}}" class="">Sub Services</a></li>
                            <li class=""><a href="{{url('admin/subservice/create')}}" class="">Add Sub Services</a></li>
                        </ul>
                    </li>
                    @endif
                    <li data-username="Permission"
                        class="nav-item pcoded-hasmenu">
                        <a href="#!" class="nav-link"><span class="pcoded-micon"><i
                                    class="fas fa-user-cog"></i></span><span
                                class="pcoded-mtext">Permission</span></a>
                        <ul class="pcoded-submenu">
                            <li class=""><a href="form_elements.html" class="">Permission</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- [ navigation menu ] end -->
