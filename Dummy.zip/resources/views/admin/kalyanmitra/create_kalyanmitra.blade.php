
@include('admin/layouts/head')
<!-- Select2 css -->
<link href="{{asset('assets/plugins/select2/css/select2.min.css')}}" rel="stylesheet">
<!-- fileupload-custom css -->
<link rel="stylesheet" href="{{asset('assets/css/pages/fileupload.css')}}">
<!-- M-Wizard css -->
<link rel="stylesheet" href="{{asset('assets/css/style.bundle.css')}}">
<!-- Material Datepicker css -->
<link href="{{asset('assets/plugins/material-datetimepicker/css/bootstrap-material-datetimepicker.css')}}" rel="stylesheet">
<!-- Bootstrap Datepicker css -->
<link href="{{asset('assets/plugins/bootstrap-datetimepicker/css/bootstrap-datepicker3.min.css')}}" rel="stylesheet">
<link href="{{asset('assets/fonts/material/css/materialdesignicons.min.css')}}" rel="stylesheet">
@include('admin/layouts/body')
@include('admin/layouts/navigation')
@include('admin/layouts/header')
@include('admin/layouts/chat_user_list')
@include('admin/layouts/chat_message')
<!-- [ Main Content ] start -->
<div class="pcoded-main-container">
   <div class="pcoded-wrapper">
      <div class="pcoded-content">
         <div class="pcoded-inner-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
               <div class="page-block">
                  <div class="row align-items-center">
                     <div class="col-md-12">
                        <div class="page-header-title">
                           <h5 class="m-b-10">Add Kalyanmitra</h5>
                        </div>
                        <ul class="breadcrumb">
                           <li class="breadcrumb-item"><a href="index-2.html"><i class="feather icon-home"></i></a></li>
                           <li class="breadcrumb-item"><a href="javascript:">Add Kalyanmitra</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
            <!-- [ breadcrumb ] end -->
            <div class="main-body">
               <div class="page-wrapper">
                  <!-- [ Main Content ] start -->
                  <div class="row">
                     <!-- [ Form Validation ] start -->
                     <div class="col-sm-12">
                        <div class="card">
                           <div class="card-header">
                              <h5>Add Kalyanmitra</h5>
                              <div class="card-header-right">
                                 <div class="btn-group card-option">
                                    <button type="button" class="btn dropdown-toggle btn-icon" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="feather icon-more-horizontal"></i>
                                    </button>
                                    <ul class="list-unstyled card-option dropdown-menu dropdown-menu-right">
                                       <li class="dropdown-item full-card"><a href="javascript:"><span><i class="feather icon-maximize"></i> maximize</span><span style="display:none"><i class="feather icon-minimize"></i> Restore</span></a></li>
                                       <li class="dropdown-item minimize-card"><a href="javascript:"><span><i class="feather icon-minus"></i> collapse</span><span style="display:none"><i class="feather icon-plus"></i> expand</span></a></li>
                                       <li class="dropdown-item reload-card"><a href="javascript:"><i class="feather icon-refresh-cw"></i> reload</a></li>
                                       <li class="dropdown-item close-card"><a href="javascript:"><i class="feather icon-trash"></i> remove</a></li>
                                    </ul>
                                 </div>
                              </div>
                           </div>
                           <div class="card-block">
                              <!--  -->
                              <!--begin: Form Wizard-->
                              <div class="m-wizard m-wizard--2 m-wizard--success" id="m_wizard">
                                 <!--begin: Message container -->
                                 <div class="m-portlet__padding-x">
                                    <!-- Here you can put a message or alert -->
                                 </div>
                                 <!--end: Message container -->
                                 <!--begin: Form Wizard Head -->
                                 <div class="m-wizard__head m-portlet__padding-x">
                                    <!--begin: Form Wizard Progress -->
                                    <div class="m-wizard__progress">
                                       <div class="progress">
                                          <div class="progress-bar" role="progressbar"  aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                                       </div>
                                    </div>
                                    <!--end: Form Wizard Progress -->
                                    <!--begin: Form Wizard Nav -->
                                    <div class="m-wizard__nav">
                                       <div class="m-wizard__steps">
                                          <div class="m-wizard__step m-wizard__step--current" m-wizard-target="m_wizard_form_step_1">
                                             <a href="#" class="m-wizard__step-number">
                                             <span>
                                             <i class="feather icon-phone"></i>
                                             </span>
                                             </a>
                                             <div class="m-wizard__step-info">
                                                <div class="m-wizard__step-title">
                                                   1. Contact Information
                                                </div>
                                             </div>
                                          </div>
                                          <div class="m-wizard__step" m-wizard-target="m_wizard_form_step_2">
                                             <a href="#" class="m-wizard__step-number">
                                             <span>
                                             <i class="fas fa-tasks"></i>
                                             </span>
                                             </a>
                                             <div class="m-wizard__step-info">
                                                <div class="m-wizard__step-title">
                                                   2. Qualification Details
                                                </div>
                                             </div>
                                          </div>
                                          <div class="m-wizard__step" m-wizard-target="m_wizard_form_step_3">
                                             <a href="#" class="m-wizard__step-number">
                                             <span>
                                             <i class="feather icon-image"></i>
                                             </span>
                                             </a>
                                             <div class="m-wizard__step-info">
                                                <div class="m-wizard__step-title">
                                                   3. Photos & Documents
                                                </div>
                                             </div>
                                          </div>
                                          <div class="m-wizard__step" m-wizard-target="m_wizard_form_step_4">
                                             <a href="#" class="m-wizard__step-number">
                                             <span>
                                             <i class="feather icon-check-square"></i>
                                             </span>
                                             </a>
                                             <div class="m-wizard__step-info">
                                                <div class="m-wizard__step-title">
                                                   4. Confirmation
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <!--end: Form Wizard Nav -->
                                 </div>
                                 <!--end: Form Wizard Head -->
                                 <!--begin: Form Wizard Form-->
                                 <div class="m-wizard__form">
                                    <!--
                                       1) Use m-form--label-align-left class to alight the form input lables to the right
                                       2) Use m-form--state class to highlight input control borders on form validation
                                       -->
                                    <form id="m_form">
                                       @csrf
                                       @method('POST')
                                       <!--begin: Form Body -->
                                       <div class="m-portlet__body">
                                          <!--begin: Form Wizard Step 1-->
                                          <div class="m-wizard__form-step" id="m_wizard_form_step_1">
                                             <div class="mt-3">
                                                <div class="row">
                                                   <div class="col-md-12 col-lg-12">
                                                      <h3 class="text-center">Kalyanmitra Details</h3>
                                                      <div class="col-md-auto col-sm-auto">
                                                         <div class="row">
                                                         <div id="step-4"></div>
                                                            <div class="col-md-6">
                                                               <div class="form-group">
                                                                  <label class="form-label font-weight-bold"><span class="text-c-red">* </span> Name</label>
                                                                  <input type="text" class="form-control" id="name" name="name" placeholder="Name" autocomplete="off" >
                                                               </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                               <div class="form-group">
                                                                  <label class="form-label font-weight-bold"><span class="text-c-red">* </span> Email</label>
                                                                  <input type="text" class="form-control" id="email" name="email" placeholder="Email" autocomplete="off">
                                                               </div>
                                                            </div>
                                                         </div>
                                                         <div class="row">
                                                            <div class="col-md-6">
                                                               <div class="form-group">
                                                                  <label class="form-label font-weight-bold"><span class="text-c-red">* </span> Mobile</label>
                                                                  <input type="text" class="form-control" id="mobile" name="mobile" placeholder="Mobile" autocomplete="off">
                                                               </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                               <div class="form-group">
                                                                  <label class="form-label font-weight-bold"><span class="text-c-red">* </span> Gender</label>
                                                                  <select class="form-control" id="gender" name="gender">
                                                                     <option value>Select</option>
                                                                     <option value="1">Male</option>
                                                                     <option value="2">Female</option>
                                                                     <option value="3">Other</option>
                                                                  </select>
                                                               </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                               <div class="form-group">
                                                                  <label class="form-label font-weight-bold"><span class="text-c-red">* </span> DOB</label>
                                                                  <input type="text" class="form-control" id="date" name="dob" placeholder="YYYY-MM-DD" autocomplete="off">
                                                               </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                               <div class="form-group">
                                                                  <label class="form-label font-weight-bold"><span class="text-c-red">* </span> Father Name</label>
                                                                  <input type="text" class="form-control" id="father_name" name="father_name" placeholder="Father Name" autocomplete="off">
                                                               </div>
                                                            </div>
                                                         </div>
                                                         <div class="row"></div>
                                                         <div class="row">
                                                            <div class="col-md-6">
                                                               <div class="form-group">
                                                                  <label class="form-label font-weight-bold"><span class="text-c-red">* </span> State</label>
                                                                  <select class="form-control" name="state" id="state">
                                                                     <option value>Select</option>
                                                                     @foreach($states as $val)
                                                                     <option value="{{$val->id}}">{{$val->name}}</option>
                                                                     @endforeach
                                                                  </select>
                                                               </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                               <div class="form-group">
                                                                  <label class="form-label font-weight-bold"><span class="text-c-red">* </span> City</label>
                                                                  <select class="form-control" name="city" id="append-city">
                                                                  <option value>Select</option>
                                                                  </select>
                                                               </div>
                                                            </div>
                                                         </div>
                                                         <div class="row">
                                                            <div class="col-md-6">
                                                               <div class="form-group">
                                                                  <label class="form-label font-weight-bold"><span class="text-c-red">* </span> District</label>
                                                                  <input type="text" class="form-control" id="district" name="district" placeholder="District" autocomplete="off">
                                                               </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                               <div class="form-group">
                                                                  <label class="form-label font-weight-bold"><span class="text-c-red">* </span> Pincode</label>
                                                                  <input type="text" class="form-control" id="pincode" name="pincode" placeholder="Pincode" autocomplete="off">
                                                               </div>
                                                            </div>
                                                         </div>
                                                         <div class="row">
                                                            <div class="col-md-6">
                                                               <div class="form-group">
                                                                  <label class="form-label font-weight-bold"><span class="text-c-red">* </span>Aadhar Number</label>
                                                                  <input type="text" class="form-control" id="aadhar_number" name="aadhar_number" placeholder="xxxx-xxxx-xxxxx" autocomplete="off">
                                                               </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                               <div class="form-group">
                                                                  <label class="form-label font-weight-bold"> Alternet Mobile</label>
                                                                  <input type="text" class="form-control" id="alternet_mobile" name="alternet_mobile" placeholder="Mobile" autocomplete="off">
                                                               </div>
                                                            </div>
                                                         </div>
                                                         <div class="row">
                                                            <div class="col-md-12">
                                                               <div class="form-group">
                                                                  <label class="form-label font-weight-bold">Locality / Landmark</label>
                                                                  <input type="text" class="form-control" id="locality_landmark" name="locality_landmark" placeholder="Locality" autocomplete="off">
                                                               </div>
                                                            </div>
                                                         </div>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!--end: Form Wizard Step 1-->
                                          <!--begin: Form Wizard Step 2-->
                                          <div class="m-wizard__form-step" id="m_wizard_form_step_2">
                                             <div class="mt-3">
                                                <div class="row">
                                                   <div class="col-md-12 col-lg-12">
                                                      <h3 class="text-center">Qualification Details </h3>
                                                      <div class="col-md-auto col-sm-auto">
                                                         <div class="row">
                                                            <div class="col-md-6">
                                                               <div class="form-group">
                                                                  <label class="form-label font-weight-bold"> <span class="text-c-red">* </span> Qualification Details </label>
                                                                  <input type="text" class="form-control" id="qualification_details" name="qualification_details" placeholder="Qualification Details " autocomplete="off">
                                                               </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                               <div class="form-group">
                                                                  <label class="form-label font-weight-bold"> specification if(any)</label>
                                                                  <input type="text" class="form-control" id="specification" name="specification" placeholder="Specification" autocomplete="off">
                                                               </div>
                                                            </div>
                                                         </div>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!--end: Form Wizard Step 2-->
                                          <!--begin: Form Wizard Step 3-->
                                          <div class="m-wizard__form-step" id="m_wizard_form_step_3">
                                             <div class="mt-3">
                                                <div class="row">
                                                   <div class="col-md-12 col-lg-12">
                                                      <h3 class="text-center">Photos & Documents</h3>
                                                      <div class="col-md-auto col-sm-auto">
                                                         <div class="row">
                                                            <div class="col-md-8 offset-2 mt-3">
                                                               <label class="form-label font-weight-bold"><span class="text-c-red">* </span> Profile Photo</label>
                                                               <div id="frmTarget" class="dropzone border-primary border-dashed">
                                                                  <div class="form-group">
                                                                     <div class="fallback">
                                                                        <input name="file" type="file" />
                                                                     </div>
                                                                     <input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
                                                                  </div>
                                                               </div>
                                                            </div>
                                                            <div class="col-md-8 offset-2 mt-3">
                                                               <label class="form-label font-weight-bold"><span class="text-c-red">* </span> Aadhar Photo</label>
                                                               <div id="frmTarget2" class="dropzone border-primary border-dashed">
                                                                  <div class="form-group">
                                                                     <div class="fallback">
                                                                        <input name="file" type="file" />
                                                                     </div>
                                                                     @csrf
                                                                  </div>
                                                               </div>
                                                            </div>
                                                         </div>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!--end: Form Wizard Step 3-->
                                          <!--begin: Form Wizard Step 4-->
                                          <div class="m-wizard__form-step" id="m_wizard_form_step_4">
                                             <div class="row">
                                                <div class="col-md-12">
                                                <div class="card-block table-border-style">
                                                <div id="div_Data" class="table-responsive">
                                             <table class="table" border="2" style="border-collapse: collapse; border-color: Black; background-color: #fff;">
                                                <tr>
                                                   <td colspan="4">

                                                            <div class="text-center">
                                                               <h1>
                                                                  Mission Bol
                                                               </h1>
                                                            </div>
                                                            <div class="text-center font-weight-bold">
                                                            L-23 R.D.Complex, Sector-3,
                                                            </div>
                                                            <div class="text-center font-weight-bold">
                                                            Awas Vikas Colony Sikandra, Agra 282001
                                                            </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td align="left" class="text-center" colspan="4"><h4> Contact Details</h4></td>
                                                </tr>
                                                <tr>
                                                   <td align="left"><span style="font-family: Arial; font-size:Small; padding-left: 10px; font-style: normal; color:#000000;"> Full Name </span></td>
                                                   <td align="left" rowspan="1" id="append-name"></td>
                                                   <td align="left"><span style="font-family: Arial; font-size:Small; padding-left: 10px; font-style: normal; color:#000000;"> Father Name </span></td>
                                                   <td align="left" id="append-father_name"></td>
                                                </tr>
                                                <tr>
                                                   <td align = "left"><span style = "font-family: Arial; font-size:Small; padding-left: 10px;  font-style: normal; color:#000000;"> Mobile Number </span></td>
                                                   <td align = "left" id="append-mobile"></td>
                                                   <td align = "left"><span style = "font-family: Arial; font-size:Small; padding-left: 10px;  font-style: normal; color:#000000;"> Alternet Mobile Number </span></td>
                                                   <td align = "left" id="append-alternet_mobile"></td>
                                                </tr>
                                                <tr>
                                                   <td align="left">
                                                      <span style="font-family: Arial; font-size:Small; padding-left: 10px; font-style: normal; color:#000000;">Email</span>
                                                   </td>
                                                   <td align="left" rowspan="1" id="append-email">
                                                   </td>
                                                   <td align="left">
                                                      <span style="font-family: Arial; font-size:Small; padding-left: 10px; font-style: normal; color:#000000;">DOB</span>
                                                   </td>
                                                   <td align="left" rowspan="1" id="append-dob">
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td align="left">
                                                      <span style="font-family: Arial; font-size:Small; padding-left: 10px;  font-style: normal; color:#000000;">Gender</span>
                                                   </td>
                                                   <td align="left" id="append-gender">
                                                   </td>
                                                   <td align="left">
                                                      <span style="font-family: Arial; font-size:Small; padding-left: 10px;  font-style: normal; color:#000000;">Aadhaar Number</span>
                                                   </td>
                                                   <td align="left" id="append-aadhar_number">
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td align="left">
                                                      <span style="font-family: Arial; font-size:Small; padding-left: 10px; font-style: normal; color:#000000;">State</span>:</span>
                                                   </td>
                                                   <td align="left" id="append-state"></td>
                                                   <td align="left">
                                                      <span style="font-family: Arial; font-size:Small; padding-left: 10px; font-style: normal; color:#000000;">
                                                      City</span>
                                                   </td>
                                                   <td align="left" id="append-city-two">

                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td align="left">
                                                      <span style="font-family: Arial; font-size:Small; padding-left: 10px; font-style: normal; color:#000000;">District</span>:</span>
                                                   </td>
                                                   <td align="left" id="append-district">

                                                   </td>
                                                   <td align="left">
                                                      <span style="font-family: Arial; font-size:Small; padding-left: 10px; font-style: normal; color:#000000;">
                                                      Pincode</span>
                                                   </td>
                                                   <td align="left" id="append-pincode">
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td align="left">
                                                      <span style="font-family: Arial; font-size:Small; padding-left: 10px; font-style: normal; color:#000000;">Landmark / Locality</span>:</span>
                                                   </td>
                                                   <td colspan="3" align="left" id="append-locality_landmark">
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td align="left" class="text-center" colspan="4"><h4> Qualification Details</h4></td>
                                                </tr>
                                                <tr>
                                                   <td align="left">
                                                      <span style="font-family: Arial; font-size:Small; padding-left: 10px; font-style: normal; color:#000000;">
                                                      Qualification Details </span>
                                                   </td>
                                                   <td align="left" id="append-qualification_details">
                                                   </td>
                                                   <td align="left"><span style="font-family: Arial; padding-left: 10px;  font-size:Small; font-style: normal; color:#000000;">Specification</span></td>
                                                   <td align="left" id="append-specification">
                                                   </td>
                                                </tr>
                                                </table>
                                                <table class="table" border="2" style="border-collapse: collapse; border-color: Black; background-color: #fff;"  id="append-table">
                                                </table>
                                          </div>
                                                </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!--end: Form Wizard Step 4-->
                                       </div>
                                       <!--end: Form Body -->
                                       <!--begin: Form Actions -->
                                       <div class="card-header"></div>
                                       <div class="mt-3">
                                          <div class="row">
                                             <div class="offset-lg-9">
                                                <a href="#" class="btn btn-secondary" data-wizard-action="prev">
                                                <span>
                                                <i class="feather icon-arrow-left"></i>
                                                &nbsp;&nbsp;
                                                <span>
                                                Back
                                                </span>
                                                </span>
                                                </a>
                                                <a href="#" class="btn btn-primary" data-wizard-action="submit">
                                                Submit
                                                </span>
                                                </span>
                                                </a>
                                                <a href="#" class="btn btn-warning" data-wizard-action="next">
                                                <span>
                                                <span>
                                                Save & Continue
                                                </span>
                                                &nbsp;&nbsp;
                                                <i class="feather icon-arrow-right"></i>
                                                </span>
                                                </a>
                                             </div>
                                          </div>
                                       </div>
                                       <!--end: Form Actions -->
                                    </form>
                                 </div>
                                 <!--end: Form Wizard Form-->
                              </div>
                              <!--end: Form Wizard-->
                           </div>
                        </div>
                     </div>
                     <!-- [ Form Validation ] end -->
                  </div>
                  <!-- [ Main Content ] end -->
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- [ Main Content ] end -->
@include('admin/layouts/footer')
<!-- jquery-validation Js -->
<script src="{{asset('assets/plugins/jquery-validation/js/jquery.validate.min.js')}}"></script>
<!-- form-picker-custom Js -->
<script src="{{asset('assets/js/pages/form-validation.js')}}"></script>
<!-- Select2 Js -->
<script src="{{asset('assets/plugins/select2/js/select2.full.min.js')}}"></script>
<!-- M-Wizard Js -->
<script src="{{asset('assets/js/b.js')}}"></script>
<script src="{{asset('assets/js/a.js')}}"></script>
<!-- Material Datepicker Js -->
<script src="{{asset('assets/plugins/material-datetimepicker/js/moment-with-locales.min.js')}}"></script>
<script src="{{asset('assets/plugins/material-datetimepicker/js/bootstrap-material-datetimepicker.js')}}"></script>
<!-- file-upload Js -->
<script src="{{asset('assets/plugins/fileupload/js/dropzone-amd-module.min.js')}}"></script>
<script>
   $(document).ready(function(){
        // [ Multi Select ] start
        $(".js-example-basic-multiple").select2({
         placeholder: "Select Your Service"
        });
        // Date Picker
        $('#date').bootstrapMaterialDatePicker({
            weekStart: 0,
            time: false
         });
       // Csrf Token
       $.ajaxSetup({
           headers: {
               'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
           }
       });
   });
   // Get Cities
   $('#state').change(function(){
      let state_id = $('#state').val();
     $.ajax({
            type: 'POST',
            url: "{{url('admin/get-cities')}}",
            data:{state_id:state_id},
            dataType: 'json',
            success: function (data) {
               // console.log(data);
            if(data.icon == 'error'){
               swal({
                  title: data.title,
                  text: data.msg,
                  type: data.icon,
                  showConfirmButton: true,
                  confirmButtonText: "OK"
               });
            }
            else{
               $('#append-city').empty();
               $('#append-city').append(data.cities);
            }
            }
         });
   });

// Profile image

Dropzone.options.frmTarget = {
	autoProcessQueue: true,
	url: "{{url('admin/upload/profile/image')}}",
	maxFilesize: 10,
	maxFiles: 1,
	timeout: 50000,
	acceptedFiles: ".jpeg,.jpg,.png",
	addRemoveLinks: true,
	init: function () {
		var myDropzone = this;

		// Update selector to match your button
		$("#button").click(function (e) {
			e.preventDefault();
			myDropzone.processQueue();
		});

		this.on('sending', function (file, xhr, formData) {
			// Append all form inputs to the formData Dropzone will POST
			var data = $('#frmTarget').serializeArray();
			$.each(data, function (key, el) {
				formData.append(el.name, el.value);
			});
			formData.append('_token', $('#csrf-token').val());
			formData.append('dir', 'kalyanmitra');
		});
	},
	removedfile: function (file) {
		var name = file.name;
		$.ajax({
			type: 'POST',
			url: '{{ url("admin/remove/profile/image") }}',
			data: {
				filename: name, dir:'kalyanmitra'
			},
			async: false,
			success: function (data) {
				if (data.icon == 'error') {
					swal({
						title: data.title,
						text: data.msg,
						icon: data.icon,
						showConfirmButton: true,
						confirmButtonText: "OK",
						closeOnConfirm: false
					});
				}
				console.log("File has been successfully removed!!");
			},
			error: function (e) {
				console.log(e);
			}
		});
		var fileRef;
		return (fileRef = file.previewElement) != null ?
			fileRef.parentNode.removeChild(file.previewElement) : void 0;
	},
	success: function (file, response) {
		if (response.icon == 'error') {
			swal({
				title: data.title,
				text: data.msg,
				icon: data.icon,
				showConfirmButton: true,
				confirmButtonText: "OK",
				closeOnConfirm: false
			});
		}
		console.log(response);
	},
	error: function (file, response) {
		return false;
	}
}


   //
   Dropzone.options.frmTarget2 = {
      autoProcessQueue: true,
      url: "{{url('admin/upload/aadhar/image')}}",
      maxFilesize: 10,
      maxFiles: 2,
      timeout: 50000,
      acceptedFiles: ".jpeg,.jpg,.png",
      addRemoveLinks: true,
      init: function() {
         var myDropzone = this;

         // Update selector to match your button
         $("#button").click(function(e) {
            e.preventDefault();
            myDropzone.processQueue();
         });

         this.on('sending', function(file, xhr, formData) {
            // Append all form inputs to the formData Dropzone will POST
            var data = $('#frmTarget2').serializeArray();
            $.each(data, function(key, el) {
               formData.append(el.name, el.value);
            });
			formData.append('_token', $('#csrf-token').val());
			formData.append('dir', 'kalyanmitra');
         });
      },
      removedfile: function(file) {
         var name = file.name;
         $.ajax({
            type: 'POST',
            url: '{{ url("admin/remove/aadhar/image") }}',
            data: {
				filename: name, dir:'kalyanmitra'
            },
            async: false,
            success: function(data) {
               if (response.icon == 'error') {
                  swal({
                     title: data.title,
                     text: data.msg,
                     icon: data.icon,
                     showConfirmButton: true,
                     confirmButtonText: "OK",
                     closeOnConfirm: false
                  });
               }
               console.log("File has been successfully removed!!");
            },
            error: function(e) {
               console.log(e);
            }
         });
         var fileRef;
         return (fileRef = file.previewElement) != null ?
            fileRef.parentNode.removeChild(file.previewElement) : void 0;
      },

      success: function(file, response) {
         if (response.icon == 'error') {
			swal({
				title: data.title,
				text: data.msg,
				icon: data.icon,
				showConfirmButton: true,
				confirmButtonText: "OK",
				closeOnConfirm: false
			});
		}
         console.log(response);
      },
      error: function(file, response) {
         return false;
      }
   }


   var WizardDemo = function () {
    $("#m_wizard");
    let stepNumber = '';
    var e, r, i = $("#m_form");
    return {
        init: function () {
            var n;
            $("#m_wizard"), i = $("#m_form"), (r = new mWizard("m_wizard", {
                startStep: 1
            })).on("beforeNext", function (r) {
                !0 !== e.form() && r.stop()
            }), r.on("change", function (e) {
               stepNumber = r.getStep();
                mUtil.scrollTop()
            }), e = i.validate({
                ignore: ":hidden",
                rules: {
                    name: {
                        required: !0
                    },
                    city: {
                        required: !0
                    },
                    state: {
                        required: !0
                    },
                    mobile: {
                        required: !0,
                        maxlength: 10,
                        minlength: 10
                    },
                    gender: {
                        required: !0
                    },
                    dob: {
                        required: !0
                    },
                    father_name: {
                        required: !0
                    },
                    district: {
                        required: !0
                    },
                    pincode: {
                        required: !0,
                        number: !0,
                        maxlength: 6,
                        minlength: 6
                    },
                    alternet_mobile: {
                        maxlength: 10,
                        minlength: 10
                    },
                    aadhar_number: {
                        required: !0,
                        maxlength: 12,
                        minlength: 12
                    },
                    qualification_details: {
                        required: !0
                    },
                    email: {
                        required: !0,
                        email: !0
                    }
                },
                messages: {
                    // description:{
                    //  required: "Please Fill Description"
                    // }
                },
            submitHandler: function (e) { }
            }), (n = i.find('[data-wizard-action="next"]')).on("click", function (r) {
               if (stepNumber == 4) {
                    let name = $('#name').val();
                    $('#append-name').empty();
                    $('#append-name').append(name);
                    let email = $('#email').val();
                    $('#append-email').empty();
                    $('#append-email').append(email);
                    let mobile = $('#mobile').val();
                    $('#append-mobile').empty();
                    $('#append-mobile').append(mobile);
                    let gender = $('#gender').val();
                    $('#append-gender').empty();
                    if(gender == 1){
                    $('#append-gender').append('Male');
                    }
                    else if(gender == 2){
                     $('#append-gender').append('Female');
                    }
                    else{
                     $('#append-gender').append('Other');
                    }
                    let dob = $('#date').val();
                    $('#append-dob').empty();
                    $('#append-dob').append(dob);
                    let father_name = $('#father_name').val();
                    $('#append-father_name').empty();
                    $('#append-father_name').append(father_name);
                    let state = $('#state').val();
                    $.ajax({
                        type: 'POST',
                        url: "{{url('admin/get-state-name')}}",
                        dataType: 'json',
                        data:{id:state},
                        success: function (res) {
                        $('#append-state').empty();
                        $('#append-state').append(res.stateName);
                        }
                    });
                    let city = $('#append-city').val();
                    $.ajax({
                        type: 'POST',
                        url: "{{url('admin/get-city-name')}}",
                        dataType: 'json',
                        data:{id:city},
                        success: function (res) {
                        $('#append-city-two').empty();
                        $('#append-city-two').append(res.cityName);
                        }
                    });
                    let district = $('#district').val();
                    $('#append-district').empty();
                    $('#append-district').append(district);
                    let pincode = $('#pincode').val();
                    $('#append-pincode').empty();
                    $('#append-pincode').append(pincode);
                    let aadhar_number = $('#aadhar_number').val();
                    $('#append-aadhar_number').empty();
                    $('#append-aadhar_number').append(aadhar_number);
                    let alternet_mobile = $('#alternet_mobile').val();
                    $('#append-alternet_mobile').empty();
                    $('#append-alternet_mobile').append(alternet_mobile);
                    let locality_landmark = $('#locality_landmark').val();
                    $('#append-locality_landmark').empty();
                    $('#append-locality_landmark').append(locality_landmark);
                    let qualification_details  = $('#qualification_details').val();
                    $('#append-qualification_details').empty();
                    $('#append-qualification_details').append(qualification_details );
                    let specification = $('#specification').val();
                    $('#append-specification').empty();
                    $('#append-specification').append(specification);

                    $.ajax({
                        type: 'GET',
                        url: "{{url('admin/get-dcoument')}}",
                        dataType: 'json',
                        success: function (res) {
                        $('#append-table').empty();
                        $('#append-table').append(res.table);
                        }
                    });
               }
            }),
                (n = i.find('[data-wizard-action="submit"]')).on("click", function (r) {
                    r.preventDefault(), e.form() && (i.ajaxSubmit({
                     type: 'POST',
                    url: "{{url('admin/kalyanmitra')}}",
                    enctype: 'multipart/form-data',
                    dataType: 'json',
                    success: function (data) {
                       console.log(data);
                     if(data.icon == 'error'){
                        swal({
                           title: data.title,
                           text: data.msg,
                           type: data.icon,
                           showConfirmButton: true,
                           confirmButtonText: "OK"
                        });
                     }
                     else{
                        swal({
                              title: "Good job",
                              text: "The application has been successfully submitted!",
                              type: "success",
                              showConfirmButton: true,
                              confirmButtonText: "OK"
                           }).then(function(result) {
                            location.href = "{{url('admin/kalyanmitra')}}";
                        });
                      }
                    }

                    }))
                })
        }
    }
   }();
   jQuery(document).ready(function () {
    WizardDemo.init()
   });
</script>
@include('admin/layouts/footer_end')
{{ch_title('Mission Bol || Add Kalyanmitra')}}
