@include('admin/layouts/head')
    <!-- data tables css -->
    <link rel="stylesheet" href="{{asset('assets/plugins/data-tables/css/datatables.min.css')}}">
@include('admin/layouts/body')
@include('admin/layouts/navigation')
@include('admin/layouts/header')
@include('admin/layouts/chat_user_list')
@include('admin/layouts/chat_message')
    <!-- [ Main Content ] start -->
    <div class="pcoded-main-container">
        <div class="pcoded-wrapper">
            <div class="pcoded-content">
                <div class="pcoded-inner-content">
                    <!-- [ breadcrumb ] start -->
                    <div class="page-header">
                        <div class="page-block">
                            <div class="row align-items-center">
                                <div class="col-md-12">
                                    <div class="page-header-title">
                                        <h5 class="m-b-10">Business Sangmitra</h5>
                                    </div>
                                    <ul class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="index-2.html"><i class="feather icon-home"></i></a></li>
                                        <li class="breadcrumb-item"><a href="javascript:">Business Sangmitra</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- [ breadcrumb ] end -->
                    <div class="main-body">
                        <div class="page-wrapper">
                            <!-- [ Main Content ] start -->
                            <div class="row">
                                 <!-- [ HTML5 Export button ] start -->
                                 <div class="col-sm-12">
                                    <div class="card">
                                        <div class="card-header">
                                            <h5>Business Sangmitra</h5>
                                            <div class="card-header-right">
                                                <div class="btn-group card-option">
                                                    <button type="button" class="btn dropdown-toggle btn-icon" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <i class="feather icon-more-horizontal"></i>
                                                    </button>
                                                    <ul class="list-unstyled card-option dropdown-menu dropdown-menu-right">
                                                        <li class="dropdown-item full-card"><a href="javascript:"><span><i class="feather icon-maximize"></i> maximize</span><span style="display:none"><i class="feather icon-minimize"></i> Restore</span></a></li>
                                                        <li class="dropdown-item minimize-card"><a href="javascript:"><span><i class="feather icon-minus"></i> collapse</span><span style="display:none"><i class="feather icon-plus"></i> expand</span></a></li>
                                                        <li class="dropdown-item reload-card"><a href="javascript:"><i class="feather icon-refresh-cw"></i> reload</a></li>
                                                        <li class="dropdown-item close-card"><a href="javascript:"><i class="feather icon-trash"></i> remove</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-block">
                                            <div class="table-responsive">
                                                <table id="key-act-button"
                                                    class="display table nowrap table-striped table-hover dt-responsive"
                                                    style="width:100%">
                                                    <thead>
                                                        <tr>
                                                            <th>Sr.No</th>
                                                            <th>Sangmitra ID</th>
                                                            <th>Name</th>
                                                            <th>Mobile Number</th>
                                                            <th>Work Name</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                    @php $i = 1; @endphp
                                                    @foreach($result as $val)
                                                        <tr>
                                                            <td>{{$i}}</td>
                                                            <td>{{$val->mitra_busines->sangmitra_id}}</td>
                                                            <td>{{$val->mitra_busines->name}}</td>
                                                            <td>{{$val->mitra_busines->mobile}}</td>
                                                            <td>{{$val->work_name}}</td>
                                                            <td><button class="btn drp-icon btn-rounded btn-outline-danger dropdown-toggle" onclick="destroy('{{encodeId($val->id)}}')" type="button"><i class="feather icon-trash"></i></button>
                                                            <a href="{{url('admin/business_sangmitra')}}/{{encodeId($val->id)}}" target="_blank" class="btn drp-icon btn-rounded btn-outline-success dropdown-toggle"><i class="feather icon-eye"></i></a>
                                                            <a href="{{url('admin/business_sangmitra')}}/{{encodeId($val->id)}}/edit" target="_blank" class="btn drp-icon btn-rounded btn-outline-warning dropdown-toggle"><i class="feather icon-edit"></i></a></td>
                                                        </tr>
                                                        @php $i++; @endphp
                                                        @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    <div class="pagination justify-content-center">
                                    {{ $result->onEachSide(1)->links() }}
                                    </div>
                                    </div>
                                </div>
                                <!-- [ HTML5 Export button ] end -->
                            </div>
                            <!-- [ Main Content ] end -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- [ Main Content ] end -->

    @include('admin/layouts/footer')
    <!-- datatable Js -->
    <script src="{{asset('assets/plugins/data-tables/js/datatables.min.js')}}"></script>
    <!-- Sweet alert Js -->
    <script src="{{asset('assets/plugins/sweetalert/js/sweetalert.min.js')}}"></script>
    <script>
    $(document).ready(function () {
        // [ HTML5-Export ] start
        $('#key-act-button').DataTable({
            dom: 'Bfrtip',
            buttons: [
                'excelHtml5',
                'pdfHtml5'
            ],
            "paging": false,
            "ordering": false
        });
    });

    $(document).ready(function () {
        // Csrf Token
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    });

    // delete service
    function destroy(id) {
        swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this sangmitra",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        type: 'DELETE',
                        url: "{{url('admin/business_sangmitra')}}/" + id,
                        dataType: 'json',
                        cache: false,
                        success: function (data) {
                            console.log(data);
                            if (data.icon == 'error') {
                                swal({
                                    title: data.title,
                                    text: data.msg,
                                    icon: data.icon,
                                    showConfirmButton: true,
                                    confirmButtonText: "OK",
                                    closeOnConfirm: false
                                });
                            } else {
                                swal({
                                    title: data.title,
                                    text: data.msg,
                                    icon: data.icon,
                                    showConfirmButton: true,
                                    confirmButtonText: "OK",
                                    closeOnConfirm: false
                                }).then(function (result) {
                                    window.location.href = "{{url('admin/business_sangmitra')}}";
                                })
                            }
                        }
                    });
                } else {
                    swal("Your Busines Sangmitra is safe!", {
                        icon: "error",
                    });
                }
            });
    }
</script>
@include('admin/layouts/footer_end')
{{ch_title('Mission Bol || Business Sangmitra')}}
