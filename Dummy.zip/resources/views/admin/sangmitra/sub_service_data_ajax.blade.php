
@for($i = 0; $i < count($sub_services); $i++)
@if(!empty($sub_services[$i][0]))
<h6 class="mt-4">{{$sub_services[$i][0]->service->name}}</h6>
<hr>
@endif
@foreach($sub_services[$i] as $val)
<div class="form-group d-inline mr-4">
<div class="checkbox-primary d-inline">
    <input type="checkbox" name="sub_services" value="{{$val->id}}">
    <label for="checkbox-p-in-1" class="cr">{{$val->name}}</label>
</div>
</div>
@endforeach
@endfor
<hr>
<div class="form-group">
<label for="description">Description</label>
<textarea id="description" name="description" class="form-control" cols="10" rows="3"></textarea>
</div>
