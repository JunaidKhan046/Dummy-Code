
@include('admin/layouts/head')
    <!-- Select2 css -->
    <link href="{{asset('assets/plugins/select2/css/select2.min.css')}}" rel="stylesheet">
<style>
    .imagePreview {
        width: 100%;
        height: 400px;
        background-position: center center;
        background:url("{{asset('assets/images/bg-images/no-image-e3699ae23f866f6cbdf8ba2443ee5c4e.jpg')}}");
        background-color:#fff;
        background-size: cover;
        background-repeat:no-repeat;
        display: inline-block;
        box-shadow:0px -3px 6px 2px rgba(0,0,0,0.2);
    }
    .imgUp
    {
    margin-bottom:15px;
    }
</style>
@include('admin/layouts/body')
@include('admin/layouts/navigation')
@include('admin/layouts/header')
@include('admin/layouts/chat_user_list')
@include('admin/layouts/chat_message')


    <!-- [ Main Content ] start -->
    <div class="pcoded-main-container">
        <div class="pcoded-wrapper">
            <div class="pcoded-content">
                <div class="pcoded-inner-content">
                    <!-- [ breadcrumb ] start -->
                    <div class="page-header">
                        <div class="page-block">
                            <div class="row align-items-center">
                                <div class="col-md-12">
                                    <div class="page-header-title">
                                        <h5 class="m-b-10">Add Sub Services</h5>
                                    </div>
                                    <ul class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="index-2.html"><i class="feather icon-home"></i></a></li>
                                        <li class="breadcrumb-item"><a href="javascript:">Add Sub Services</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- [ breadcrumb ] end -->
                    <div class="main-body">
                        <div class="page-wrapper">
                            <!-- [ Main Content ] start -->
                            <div class="row">
                                <!-- [ Form Validation ] start -->
                                <div class="col-sm-12">
                                    <div class="card">
                                        <div class="card-header">
                                            <h5>Add Sub Services</h5>
                                            <div class="card-header-right">
                                                <div class="btn-group card-option">
                                                    <button type="button" class="btn dropdown-toggle btn-icon" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <i class="feather icon-more-horizontal"></i>
                                                    </button>
                                                    <ul class="list-unstyled card-option dropdown-menu dropdown-menu-right">
                                                        <li class="dropdown-item full-card"><a href="javascript:"><span><i class="feather icon-maximize"></i> maximize</span><span style="display:none"><i class="feather icon-minimize"></i> Restore</span></a></li>
                                                        <li class="dropdown-item minimize-card"><a href="javascript:"><span><i class="feather icon-minus"></i> collapse</span><span style="display:none"><i class="feather icon-plus"></i> expand</span></a></li>
                                                        <li class="dropdown-item reload-card"><a href="javascript:"><i class="feather icon-refresh-cw"></i> reload</a></li>
                                                        <li class="dropdown-item close-card"><a href="javascript:"><i class="feather icon-trash"></i> remove</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-block">
                                            <form id="validation-form123">
                                            @csrf
                                            @method('PATCH')
                                                <div class="row">
                                                    <div class="offset-md-3 col-md-6">
                                                        <div class="form-group">
                                                            <label class="form-label">Select Service</label>
                                                            <select class="js-example-basic-single form-control" name="services_id" required>
                                                                <option value="">Plese Select</option>
                                                                @foreach($service as $val)
                                                                <option <?php if ($sub_service->services_id == $val->id) {echo 'selected';}?> value="{{$val->id}}">{{$val->name}}</option>
                                                                @endforeach
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="offset-md-3 col-md-6">
                                                        <div class="form-group">
                                                            <label class="form-label">Name</label>
                                                            <input type="text" class="form-control" name="name" placeholder="Name" required value="{{$sub_service->name}}">
                                                        </div>
                                                    </div>
                                                    <div class="offset-md-3 col-md-6">
                                                        <div class="form-group">
                                                            <label class="form-label">Description</label>
                                                            <textarea class="form-control" name="description" required>{{$sub_service->description}}</textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                                <button type="button" class="offset-md-3 btn btn-primary update_subservice"><span id="loader"></span>Submit</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <!-- [ Form Validation ] end -->
                            </div>
                            <!-- [ Main Content ] end -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- [ Main Content ] end -->

@include('admin/layouts/footer')
    <!-- jquery-validation Js -->
    <script src="{{asset('assets/plugins/jquery-validation/js/jquery.validate.min.js')}}"></script>
    <!-- form-picker-custom Js -->
    <script src="{{asset('assets/js/pages/form-validation.js')}}"></script>
    <!-- Sweet alert Js -->
    <script src="{{asset('assets/plugins/sweetalert/js/sweetalert.min.js')}}"></script>
    <!-- Select2 Js -->
    <script src="{{asset('assets/plugins/select2/js/select2.full.min.js')}}"></script>
    <script>
    $(document).ready(function(){
         // [ Single Select ] start
         $(".js-example-basic-single").select2();
        // Csrf Token
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    });

$('.update_subservice').click(function(){
    if ($('#validation-form123').valid()) {
       var form = $('#validation-form123')[0];
             var formData = new FormData(form);
             $.ajax({
                 type: 'POST',
                 url: "{{route('subservice.update', $sub_service->id)}}",
                 data: formData,
                 enctype: 'multipart/form-data',
                 dataType: 'json',
                 cache: false,
                 contentType: false,
                 processData: false,
                 beforeSend:function(){
                     $('#loader').empty();
                     $('.add_service').attr("disabled", true);
                     $('#loader').append('<span class="spinner-border spinner-border-sm" role="status"></span>  ');
                 },
                 success: function (data) {
                    if(data.icon == 'error'){
                     swal({
                         title: data.title,
                         text: data.msg,
                         icon: data.icon,
                         showConfirmButton: true,
                         confirmButtonText: "OK",
                         closeOnConfirm: false
                     });
                    }
                    else {
                     swal({
                         title: data.title,
                         text: data.msg,
                         icon: data.icon,
                         showConfirmButton: true,
                         confirmButtonText: "OK",
                         closeOnConfirm: false
                     }).then(function (result) {
                         window.location.href = "{{url('admin/subservice')}}";
                     })
                  }
                 }
             });
    }
   });
    </script>
@include('admin/layouts/footer_end')
{{ch_title('Mission Bol || Add Sub Services')}}
