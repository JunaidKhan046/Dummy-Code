<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
 */

Route::get('/', function () {
    return view('welcome');
});

Route::prefix('admin')->group(function () {
    Auth::routes();
    Auth::routes(['verify' => true]);
    Route::get('/home', 'Admin\HomeController@index')->name('home');
    /**--------------------------------------------------------------- */
    // Start Services
    Route::resource('/service', 'Admin\ServiceController');
    Route::post('/update-service-status', 'Admin\ServiceController@update_service_status');
    // End Services
    /**--------------------------------------------------------------- */
    // Start Sub Services
    Route::post('/update-subservice-status', 'Admin\SubServiceController@update_subservice_status');
    Route::resource('/subservice', 'Admin\SubServiceController');
    // End Sub Services
    /**--------------------------------------------------------------- */
    // Start Business Sangmitra
    Route::resource('/business_sangmitra', 'Admin\BusinessSangmitra');
    Route::post('/append-sub-service', 'Admin\BusinessSangmitra@appendSubservice');
    Route::post('/upload/profile/image', 'Admin\BusinessSangmitra@uploadProfileImage');
    Route::post('/remove/profile/image', 'Admin\BusinessSangmitra@fileDestroyProfile');
    Route::post('/upload/aadhar/image', 'Admin\BusinessSangmitra@uploadAadharImage');
    Route::post('/remove/aadhar/image', 'Admin\BusinessSangmitra@fileDestroyAadhar');
    Route::post('/upload/working/docs', 'Admin\BusinessSangmitra@uploadWorkingDocs');
    Route::post('/remove/working/docs', 'Admin\BusinessSangmitra@fileDestroyWorkingDocs');
    Route::post('/upload/working/photo', 'Admin\BusinessSangmitra@uploadWorkingPhoto');
    Route::post('/remove/working/photo', 'Admin\BusinessSangmitra@fileDestroyWorkingPhoto');
    Route::post('/upload/qualification/docs', 'Admin\BusinessSangmitra@uploadQualificationDocs');
    Route::post('/remove/qualification/docs', 'Admin\BusinessSangmitra@fileDestroyQualificationDocs');
    // End Business Sangmitra
    /**--------------------------------------------------------------- */
    // Start Goverment Sangmitra
    Route::resource('/goverment_sangmitra', 'Admin\GovermentSangmitra');
    // End Goverment Sangmitra
    /**--------------------------------------------------------------- */
    // Start Private Sangmitra
    Route::resource('/private_sangmitra', 'Admin\PrivateSangmitra');
    // End Private Sangmitra
    /**--------------------------------------------------------------- */
    // Start Kalyanmitra
    Route::resource('/kalyanmitra', 'Admin\Kalyanmitra');
    Route::post('/update-kalyanmitra-status', 'Admin\Kalyanmitra@update_kalyanmitra_status');
    Route::get('/get/kalyanmitra/profile/image/{id}', 'Admin\Kalyanmitra@getProfileImage');
    // End Kalyanmitra
    /**--------------------------------------------------------------- */
    // Start Sub Admin
    Route::resource('/subadmin', 'Admin\SubAdminController');
    Route::post('/update-subadmin-status', 'Admin\SubAdminController@update_subadmin_status');
    // End Sub Admin
    /**----------------------------------------------------------------*/
    // Get Cities
    Route::post('/get-cities', 'Admin\CommonController@getCities');
    Route::post('/get-state-name', 'Admin\CommonController@getStateName');
    Route::post('/get-city-name', 'Admin\CommonController@getCityName');
    Route::post('/get-service-name', 'Admin\CommonController@getServiceName');
    Route::post('/get-sub-service-name', 'Admin\CommonController@getSubServiceName');
    Route::get('/get-dcoument', 'Admin\CommonController@getDcoument');

});

/**-------------------------------------------------------------------- */
// Kalyanmitra auth start here
Route::prefix('kalyanmitra')->group(function () {
    Route::get('/login', 'Auth\KalyanmitraLoginController@showLoginForm')->name('kalyanmitra.formlogin');
    Route::post('/login/check', 'Auth\KalyanmitraLoginController@login')->name('kalyanmitra.login');
    Route::post('/logout', 'Auth\KalyanmitraLoginController@logout')->name('kalyanmitra.logout');
// Password Reset
    Route::post('/password/email', 'Auth\KalyanmitraForgotPasswordController@sendResetLinkEmail')->name('kalyanmitra.password.email');
    Route::get('/password/reset', 'Auth\KalyanmitraForgotPasswordController@showLinkRequestForm')->name('kalyanmitra.password.update');
    Route::post('/password/reset', 'Auth\KalyanmitraResetController@reset');
    Route::get('/password/reset/{token}', 'Auth\KalyanmitraResetController@showResetForm')->name('kalyanmitra.password.reset');
// Email Verification
    Route::get('/email/resend', 'Auth\KalyanmitraVerificationController@resend')->name('kalyanmitra.verification.resend');
    Route::get('/email/verify', 'Auth\KalyanmitraVerificationController@show')->name('kalyanmitra.verification.notice');
    Route::get('/email/verify/{id}', 'Auth\KalyanmitraVerificationController@verify')->name('kalyanmitra.verification.verify');
    // Dashboard
    Route::get('/home', 'Kalyanmitra\KalyanmitraController@index');
    // Start Business Sangmitra
    Route::resource('/business_sangmitra', 'Kalyanmitra\BusinessSangmitra');
    Route::post('/append-sub-service', 'Kalyanmitra\BusinessSangmitra@appendSubservice');
    Route::post('/upload/profile/image', 'Kalyanmitra\BusinessSangmitra@uploadProfileImage');
    Route::post('/remove/profile/image', 'Kalyanmitra\BusinessSangmitra@fileDestroyProfile');
    Route::post('/upload/aadhar/image', 'Kalyanmitra\BusinessSangmitra@uploadAadharImage');
    Route::post('/remove/aadhar/image', 'Kalyanmitra\BusinessSangmitra@fileDestroyAadhar');
    Route::post('/upload/working/docs', 'Kalyanmitra\BusinessSangmitra@uploadWorkingDocs');
    Route::post('/remove/working/docs', 'Kalyanmitra\BusinessSangmitra@fileDestroyWorkingDocs');
    Route::post('/upload/working/photo', 'Kalyanmitra\BusinessSangmitra@uploadWorkingPhoto');
    Route::post('/remove/working/photo', 'Kalyanmitra\BusinessSangmitra@fileDestroyWorkingPhoto');
    // End Business Sangmitra
    /**--------------------------------------------------------------- */
    // Start Goverment Sangmitra
    Route::resource('/goverment_sangmitra', 'Kalyanmitra\GovermentSangmitra');
    // End Goverment Sangmitra
    /**--------------------------------------------------------------- */
    // Start Private Sangmitra
    Route::resource('/private_sangmitra', 'Kalyanmitra\PrivateSangmitra');
    // End Private Sangmitra
    /**--------------------------------------------------------------- */
});
// Kalyanmitra auth End here

/**-------------------------------------------------------------------- */
// Sub admin auth start here
Route::prefix('subadmin')->group(function () {
    Route::get('/login', 'Auth\SubAdminLoginController@showLoginForm')->name('subadmin.formlogin');
    Route::post('/login/check', 'Auth\SubAdminLoginController@login')->name('subadmin.login');
    Route::post('/logout', 'Auth\SubAdminLoginController@logout')->name('subadmin.logout');
// Password Reset
    Route::post('/password/email', 'Auth\SubAdminForgotPasswordController@sendResetLinkEmail')->name('subadmin.password.email');
    Route::get('/password/reset', 'Auth\SubAdminForgotPasswordController@showLinkRequestForm')->name('subadmin.password.update');
    Route::post('/password/reset', 'Auth\SubAdminResetController@reset');
    Route::get('/password/reset/{token}', 'Auth\SubAdminResetController@showResetForm')->name('subadmin.password.reset');
// Email Verification
    Route::get('/email/resend', 'Auth\SubAdminVerificationController@resend')->name('subadmin.verification.resend');
    Route::get('/email/verify', 'Auth\SubAdminVerificationController@show')->name('subadmin.verification.notice');
    Route::get('/email/verify/{id}', 'Auth\SubAdminVerificationController@verify')->name('subadmin.verification.verify');
    // Dashboard
    Route::get('/home', 'SubAdmin\SubAdminController@index');
    // Start Business Sangmitra
    // Route::resource('/business_sangmitra', 'Kalyanmitra\BusinessSangmitra');
    // Route::post('/append-sub-service', 'Kalyanmitra\BusinessSangmitra@appendSubservice');
    // Route::post('/upload/profile/image', 'Kalyanmitra\BusinessSangmitra@uploadProfileImage');
    // Route::post('/remove/profile/image', 'Kalyanmitra\BusinessSangmitra@fileDestroyProfile');
    // Route::post('/upload/aadhar/image', 'Kalyanmitra\BusinessSangmitra@uploadAadharImage');
    // Route::post('/remove/aadhar/image', 'Kalyanmitra\BusinessSangmitra@fileDestroyAadhar');
    // Route::post('/upload/working/docs', 'Kalyanmitra\BusinessSangmitra@uploadWorkingDocs');
    // Route::post('/remove/working/docs', 'Kalyanmitra\BusinessSangmitra@fileDestroyWorkingDocs');
    // Route::post('/upload/working/photo', 'Kalyanmitra\BusinessSangmitra@uploadWorkingPhoto');
    // Route::post('/remove/working/photo', 'Kalyanmitra\BusinessSangmitra@fileDestroyWorkingPhoto');
    // End Business Sangmitra
    /**--------------------------------------------------------------- */
    // Start Goverment Sangmitra
    // Route::resource('/goverment_sangmitra', 'Kalyanmitra\GovermentSangmitra');
    // End Goverment Sangmitra
    /**--------------------------------------------------------------- */
    // Start Private Sangmitra
    // Route::resource('/private_sangmitra', 'Kalyanmitra\PrivateSangmitra');
    // End Private Sangmitra
    /**--------------------------------------------------------------- */
});
// Kalyanmitra auth End here
